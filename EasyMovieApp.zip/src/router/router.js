import { createRouter, createWebHashHistory } from "vue-router";
import { useMainStore } from "@/pinia/mainStore.js";

import { storeToRefs } from "pinia";
import { ElMessage } from "element-plus";
import administrator from "@/api/users/Administrator";
const login = () => import("@/views/admin/login.vue");
const mainPage = () => import("@/views/admin/main.vue");
const movieHouseUpdata = () => import("@/views/admin/movieHouseUpdata.vue");
const movieHouseInfo = () => import("@/views/admin/movieHouseInfo.vue");
const seatInfo = () => import("@/views/admin/movieHouseSeat.vue");
const tagSearch = () => import("@/views/admin/tagSearch.vue");
const tagList = () => import("@/views/admin/tagList.vue");
const filmInfo = () => import("@/views/admin/filmInfo.vue");
const filmUpdate = () => import("@/views/admin/filmUpdate.vue");
const movieSetInfo = () => import("@/views/admin/movieSetInfo.vue");
const movieSetUpdate = () => import("@/views/admin/movieSetUpdate.vue");
const voucherInfo = () => import("@/views/admin/voucherInfo.vue");
const voucherUpdate = () => import("@/views/admin/voucherUpdate.vue");
const routes = [
  {
    path: "/",
    name: "/",
    redirect: { path: "/main/sy" },
  },
  //后台管理登录首页
  {
    path: "/admin/login",
    name: "adminLogin",
    component: login,
    meta: { name: "后台管理登录页", power: -2, keepAlive: false },
  },

  //后台管理主界面
  {
    path: "/admin/main",
    name: "main",
    component: mainPage,
    meta: { name: "后台管理主界面", power: 1 },
    redirect: { path: "/admin/main/movieHouse" },
    children: [
      //添加放映厅
      {
        name: "addMovieHouse",
        path: "movieHouse/add",
        component: movieHouseUpdata,
        meta: { breadcrumbName: "添加放映厅", keepAlive: false },
      },
      //放映厅查看
      {
        name: "movieHouseInfo",
        path: "movieHouse/info",
        component: movieHouseInfo,
        meta: { breadcrumbName: "查看放映厅", keepAlive: false },
      },
      //放映厅更新信息
      {
        name: "updateMovieHouse",
        path: "movieHouse/update/:id",
        component: movieHouseUpdata,
        meta: { breadcrumbName: "更新放映厅", keepAlive: false },
      },
      //放映厅座位信息
      {
        name: "movieHouseSeat",
        path: "movieHouse/seatInfo/:id",
        component: seatInfo,
        meta: { breadcrumbName: "放映厅位置信息", keepAlive: false },
      },
      //电影信息管理
      {
        name: "filmInfo",
        path: "film/info",
        component: filmInfo,
        meta: { breadcrumbName: "电影列表", keepAlive: false },
      },
      {
        name: "filmUpdate",
        path: "film/update/:id",
        component: filmUpdate,
        meta: { breadcrumbName: "更新电影列表", keepAlive: false },
      },
      {
        name: "filmAdd",
        path: "film/add",
        component: filmUpdate,
        meta: { breadcrumbName: "添加电影列表", keepAlive: false },
      },
      //电影标签管理
      {
        name: "search",
        path: "tag/search",
        component: tagSearch,
        meta: { breadcrumbName: "电影标签查看", keepAlive: false },
      },
      //电影标签修改
      {
        name: "list",
        path: "tag/list/:tagName",
        component: tagList,
        meta: { breadcrumbName: "电影标签列表", keepAlive: false },
      },
      //添加电影标签
      {
        name: "addTag",
        path: "tag/add",
        component: tagList,
        meta: { breadcrumbName: "添加电影标签", keepAlive: false },
      },
      //排片管理
      {
        name: "SetList",
        path: "movieSet/info",
        component: movieSetInfo,
        meta: { breadcrumbName: "电影排片", keepAlive: false },
      },
      //排片添加
      {
        name: "addSet",
        path: "movieSet/add",
        component: movieSetUpdate,
        meta: { breadcrumbName: "电影排片添加", keepAlive: false },
      },
      //排片修改
      {
        name: "updateSet",
        path: "movieSet/update/:id",
        component: movieSetUpdate,
        meta: { breadcrumbName: "电影排片修改", keepAlive: false },
      },
      //优惠券发布
      {
        name: "voucher",
        path: "voucher/info",
        component: voucherInfo,
        meta: { breadcrumbName: "优惠券管理", keepAlive: false },
      },
      //优惠券添加
      {
        name: "voucherAdd",
        path: "voucher/add",
        component: voucherUpdate,
        meta: { breadcrumbName: "优惠券添加", keepAlive: false },
      },
      //优惠券修改
      {
        name: "voucherUpdate",
        path: "voucher/update/:id",
        component: voucherUpdate,
        meta: { breadcrumbName: "优惠券修改", keepAlive: false },
      },
      //演员信息
      {
        name: "adminPerformer",
        path: "performer/info",
        component: () => import("@/views/admin/performerInfo.vue"),
        meta: { breadcrumbName: "演员列表", keepAlive: false },
      },
      //演员信息添加
      {
        name: "performerAdd",
        path: "performer/add",
        component: () => import("@/views/admin/performerUpdate.vue"),
        meta: { breadcrumbName: "演员添加", keepAlive: false },
      },
      //演员信息修改
      {
        name: "performerUpdate",
        path: "performer/update/:id",
        component: () => import("@/views/admin/performerUpdate.vue"),
        meta: { breadcrumbName: "演员修改", keepAlive: false },
      },
    ],
  },
  //app登录界面
  {
    path: "/login",
    name: "login",
    component: () => import("@/views/login/login.vue"),
    meta: { name: "登录界面" },
  },
  //app首页
  {
    path: "/main",
    name: "AppMain",
    component: () => import("@/components/main.vue"),
    redirect: { path: "/main/sy" },
    meta: { name: "主界面", keepAlive: false },
    children: [
      //首页
      {
        name: "sy",
        path: "sy",
        component: () => import("@/views/sy/sy.vue"),
        meta: { name: "首页", keepAlive: true },
      },
      //电影院
      {
        name: "cinema",
        path: "cinema",
        component: () => import("@/views/cinema/cinema.vue"),
        meta: { name: "电影院", keepAlive: true },
      },
      //指定电影的电影院
      {
        name: "cinema1",
        path: "cinema/:filmName",
        component: () => import("@/views/cinema/cinema.vue"),
        meta: { name: "电影院电影名字", keepAlive: false },
      },
      //我的
      {
        name: "me",
        path: "me",
        component: () => import("@/views/me/me.vue"),
        meta: { name: "我的", keepAlive: true },
      },
    ],
  },
  //电影相关
  {
    path: "/movie",
    redirect: { path: "/movie/1" },
  },
  //电影院详情页
  {
    path: "/cinemaInfo/:cinemaID/:filmID?",
    name: "cinemaInfo",
    component: () => import("@/views/cinema/cinemaInfo.vue"),
  },
  //电影排片选择电影座位
  {
    path: "/bought/movieSet/:movieSetID",
    name: "buyMousehouse",
    component: () => import("@/views/bought/movieSet.vue"),
  },
  //订单界面
  {
    path: "/bought/order/:orderID",
    name: "order",
    component: () => import("@/views/bought/order.vue"),
  },
  //电影详情页
  {
    path: "/movie/:id",
    name: "movie",
    component: () => import("@/views/movie/movie.vue"),
    meta: { name: "电影首页", keepAlive: false },
  },
  //演员详情页
  {
    path: "/movie/performer/:id",
    name: "performer",
    component: () => import("@/views/movie/performer.vue"),
    meta: { name: "演员详情", keepAlive: false },
  },
  //我的购票
  {
    name: "filmOrder",
    path: "/main/filmOrder",
    component: () => import("@/views/me/filmOrder.vue"),
    meta: { breadcrumbName: "我的购票", keepAlive: false },
  },
  //我的优惠券
  {
    name: "voucherOrder",
    path: "/main/voucher",
    component: () => import("@/views/me/voucher.vue"),
    meta: { breadcrumbName: "我的优惠券", keepAlive: false },
  },

  //404
  {
    path: "/:pathMatch(.*)*",
    name: "404",
    component: () => import("@/components/404.vue"),
  },
];
const router = createRouter({
  history: createWebHashHistory(),
  routes, // `routes: routes` 的缩写
});
const whiteList = ["/", "/login", "/admin/login"];
//路由守卫
router.beforeEach(async (to, from) => {
  //只有不在白名单中才能进行路由守卫判断
  if (!whiteList.includes(to.fullPath)) {
    console.log(to);
    console.log(from);
    const mainStore = useMainStore();
    // 检查有没有查到用户的ID,
    // 如果没有就检查有没有 localhost中有没有token ,有就发送请求用token获取数据,没有就直接跳回
    let token = localStorage.getItem("token") || null;
    if (mainStore.userId == null) {
      //如果token为空
      if (token == null) {
        ElMessage({
          showClose: true,
          message: "未登录返回登录页面",
          type: "warning",
        });
        router.push("login");
        return false;
      }
      //发送请求获取用户信息
      await administrator.getInfo().then((res) => {
        mainStore.userId = res.id;
        mainStore.cinemaId = res.cinemaId;
        mainStore.name = res.name;
        mainStore.account = res.account;
        mainStore.avatarUrl = res.avatarUrl;
        mainStore.power = res.power;
        mainStore.type = res.type;
      });
    }

    //判断权限够不够
    if (mainStore.power < to.meta.power) {
      ElMessage({
        showClose: true,
        message: "权限不足,返回登录界面",
        type: "warning",
      });
      router.push("admin/login");
      return false;
    }
  }
});
export default router;
