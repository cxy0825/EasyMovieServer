import axios from "axios";
import { ElMessage } from "element-plus";
import router from "@/router/router.js";
// const baseUrl = "http://localhost";
const baseUrl = "http://192.168.2.6";
//创建axios
const service = axios.create({
  baseURL: baseUrl,
  timeout: 10000,
});
//请求拦截器
//让每个请求发送前都带上token请求头
service.interceptors.request.use(
  (config) => {
    //获取loaclStorage中的token和refreshToken
    let token =
      localStorage.getItem("token") == null
        ? ""
        : localStorage.getItem("token");
    // 添加到请求头中
    config.headers["token"] = token;
    return config;
  },
  (error) => {
    console.log(error);
    return Promise.reject(error);
  }
);
//返回响应拦截器
service.interceptors.response.use(
  (response) => {
    //状态码不为20000就弹出错误
    if (response.data.code != 20000) {
      ElMessage({
        showClose: true,
        message: response.data.message || "状态返回异常",
        type: "error",
      });
      if (response.data.code === 10004) {
        router.push("/login");
      }
      return Promise.reject(new Error(response.data.message || "状态返回异常"));
    }
    if (response.data.message != "成功") {
      ElMessage({
        showClose: true,
        message: response.data.message || "成功",
        type: "success",
      });
    }

    return response.data.data;

    // //登录过期,或者权限不足就跳回到登录界面
    // if (response.data.code === 10004) {
    //   ElMessage({
    //     showClose: true,
    //     message: response.data.message || "发生错误,信息未知",
    //     type: "warning",
    //   }).then(() => {
    //     window.location.href = "/admin/login";
    //   });
    //   return Promise.reject(
    //     new Error(response.data.message || "发生错误,信息未知")
    //   );
    // } else {
    //   return response.data.data;
    // }
  },
  (error) => {
    ElMessage({
      showClose: true,
      message: error.message || "请求接受返回错误",
      type: "error",
    });
    console.log(error);
    return Promise.reject(error);
  }
);
export default service;
