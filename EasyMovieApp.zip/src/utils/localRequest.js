import axios from "axios";
import { ElMessage } from "element-plus";
import router from "@/router/router.js";
// const baseUrl = "http://localhost";
const baseUrl = "local";
//创建axios
const service = axios.create({
  baseURL: baseUrl,
  timeout: 10000,
});
//请求拦截器
//让每个请求发送前都带上token请求头
service.interceptors.request.use(
  (config) => {
    // 把高德的key添加到请求头中
    config.params = {
      key: "263f4aaca1dbeed5c8a822a85260c476",
    };
    return config;
  },
  (error) => {
    console.log(error);
    return Promise.reject(error);
  }
);
//返回响应拦截器
service.interceptors.response.use(
  (response) => {
    //状态码不为20000就弹出错误
    if (response.data.infocode != 10000) {
      ElMessage({
        showClose: true,
        message: response.data.message || "状态返回异常",
        type: "error",
      });

      return Promise.reject(new Error(response.data.message || "状态返回异常"));
    }

    return response.data;
  },
  (error) => {
    ElMessage({
      showClose: true,
      message: error.message || "请求接受返回错误",
      type: "error",
    });
    console.log(error);
    return Promise.reject(error);
  }
);
export default service;
