import { defineStore } from "pinia";
export const useMainStore = defineStore("main", {
  state: () => {
    return {
      userId: null,
      cinemaId: null,
      name: "未登录",
      account: null,
      power: -1,
      type: null,
      avatarUrl: null,
      location: "28.639338095,121.3837552",
    };
  },
  getters: {},
  actions: {},
});
