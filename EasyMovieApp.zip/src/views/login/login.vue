<script setup>
import { ref, reactive } from "vue";
import { storeToRefs } from "pinia";
import { ElMessage } from "element-plus";
import user from "@/api/users/user.js";
import { useMainStore } from "@/pinia/mainStore.js";
import { useRouter } from "vue-router";
const mainStore = useMainStore();
const router = useRouter();
let phone = ref("");
let code = ref("");
let codeText = ref("获取验证码");
function zfb() {
  alert("支付宝快捷登录");
}
function getCode() {
  //手机号为空
  if (phone.value == "") {
    ElMessage({
      message: "请输入手机号码",
      type: "warning",
    });
    return false;
  }
  //获取验证码
  user.getCode(phone.value).then((res) => {
    let count = 60;
    codeText.value = count + "秒后可获取";
    const time = setInterval(() => {
      count--;
      codeText.value = count + "秒后可获取";
      if (count == 0) {
        codeText.value = "获取验证码";
        count = 60;
        clearInterval(time);
      }
    }, 1000);
  });
}
function login() {
  let data = {
    account: phone.value,
    password: code.value,
    type: "em",
  };
  user
    .login(data)
    .then((res) => {
      //把token存在localstore中 并且获取数据
      localStorage.setItem("token", res);
      return user.getInfo();
    })
    .then((res) => {
      //把用户信息写入到pinia
      console.log(res);
      mainStore.userId = res.id;
      mainStore.cinemaId = 0;
      mainStore.name = res.name;
      mainStore.account = res.account;
      mainStore.power = res.power;
      mainStore.type = res.type;
      mainStore.avatarUrl = res.avatarUrl;
      //跳转到首页
      router.push("/main/sy");
    });
}
</script>
<template>
  <div class="root">
    <div class="bg"></div>
    <div class="icon">
      <div class="icon-item">
        <img src="@/assets/static/img/movie_ico.png" alt="" />
      </div>
      <div class="text">EM电影</div>
    </div>
    <div class="login">
      <el-input v-model="phone" placeholder="请输入手机号" class="phone" />
      <div class="form-group">
        <el-input v-model="code" placeholder="验证码" class="code" />
        <el-button
          type="primary"
          round
          @click="getCode"
          :disabled="codeText != '获取验证码'"
          >{{ codeText }}</el-button
        >
      </div>
      <el-button
        type="primary"
        round
        class="submit"
        @click="login"
        :disabled="!(phone != '' && code != '')"
        >登录</el-button
      >
    </div>
    <div class="divider">
      <div class="h"></div>
      <span>合作商家</span>
      <div class="h"></div>
    </div>
    <div class="container">
      <div class="item">
        <img src="@/assets/static/img/支付宝.png" alt="" @click="zfb" />
      </div>
    </div>
  </div>
</template>

<style scoped>
.root {
  width: 100vw;
  height: 100vh;

  display: flex;
  flex-direction: column;
  position: relative;
  z-index: 1;
  justify-content: center;
  align-items: center;
}
.bg {
  width: 100vw;
  height: 100vh;
  position: absolute;
  left: 0;
  top: 0;
  z-index: -100;
  background: url("@/assets/static/img/login_bg.png");
  /* background-size: 100% 100%; */
  background-repeat: no-repeat;
  background-position: center;
  filter: brightness(0.55);
}
.icon {
  width: 100px;
}

.icon .icon-item img {
  width: 100%;
  height: 100%;
}
.icon .text {
  width: 100%;
  text-align: center;
  color: white;
  font-size: 22px;
  margin-top: 5px;
}
.login {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin-top: 30px;
}
.phone {
  width: 90%;
  height: 40px;
}
.phone >>> .el-input__wrapper {
  border-radius: 20px;
  padding: 0 20px;
}
.form-group {
  width: 90%;
  display: flex;
  justify-content: space-between;

  margin-top: 20px;
}
.code {
  width: 60%;
  height: 40px;
}
.code >>> .el-input__wrapper {
  border-radius: 20px;
  padding: 0 20px;
}

.form-group .el-button {
  width: 100px;
  height: 40px;
  margin-left: 40px;
}
.submit {
  margin-top: 20px;
  width: 90%;
  height: 40px;
}
.divider {
  width: 90%;
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  margin-top: 20px;
}
.divider .h {
  width: 25%;
  height: 1px;
  background-color: white;
}
.divider span {
  font-size: 16px;
  color: white;
}
.container {
  width: 90%;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.container .item {
  width: 30px;
  height: 30px;
  cursor: pointer;
}
.container .item img {
  width: 100%;
  height: 100%;
}
</style>
