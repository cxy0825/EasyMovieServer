<script setup>
import { ref, reactive, onMounted, onActivated, computed } from "vue";
import { useRouter, useRoute } from "vue-router";
import movieApi from "@/api/movie/movieApi.js";
import movieSet from "@/api/movie/movieSet.js";
import cinemaApi from "@/api/movie/cinemaApi.js";
import { useMainStore } from "@/pinia/mainStore.js";
import { indexOf, sortedUniq } from "lodash";

const mainStore = useMainStore();
const router = useRouter();
const route = useRoute();
const filmName = route.params.filmName;

//下拉获取电影院信息
const cinemaInfo = reactive({
  data: [],
});
const filmInfo = reactive({
  data: [{ price: "---" }],
});
//当前第几页
const page = ref(1);
//纬度
let location = mainStore.location.split(",");
const x = location[0];
const y = location[1];

//初始化获取数据
function init() {
  if (route.name != "cinema" && route.name != "cinema1") {
    return false;
  }
  if (filmName != undefined) {
    cinemaApi
      .getCinemaInfoByFilmName(x, y, filmName, page.value, 8, sort.value)
      .then((cinemaRes) => {
        // console.log(cinemaRes);

        cinemaInfo.data.push(...cinemaRes);
        if (filmInfo.data[0].price == "---") {
          filmInfo.data.length = 0;
        }
        //如果filmName存在就根据id获取改电影票价格
        if (cinemaRes.length > 0) {
          cinemaRes.forEach((item) => {
            movieSet
              .getMovieSetInfoByName(item.id, filmName)
              .then((movieSetRes) => {
                filmInfo.data.push(movieSetRes.records[0]);
              });
          });
        }
      });
  } else {
    cinemaApi.getCinemaInfo(x, y, page.value, 8, sort.value).then((res) => {
      cinemaInfo.data.push(...res);
      res.forEach(() => {
        filmInfo.data.push({ price: "---" });
      });
    });
  }

  page.value++;
}

function load() {
  init();
}

//距离保留小数点后一位单位km
const distanceInit = computed(() => {
  return (str) => {
    str = str + ""; //强转成字符串

    let length = str.indexOf(".");

    // console.log(length);

    return str.substring(0, length >= 1 ? length + 2 : str.length);
  };
});
const price = computed(() => {
  return (obj) => {
    if (obj == undefined) {
      return "---";
    }
    return obj.price;
  };
});
//点击改变排序
const sort = ref("asc");
function getDistance(str) {
  sort.value = str;

  page.value = 1;
  //清除原先的数据
  cinemaInfo.data.length = 0;
  filmPrice.value.length = 0;
  init();
}

onMounted(() => {
  init();
});

//去指定的电影院界面
function toCinemaInfoView(cinemaID, filmID) {
  //去指定电影名字的页面
  if (filmID != undefined) {
    router.push(`/cinemaInfo/${cinemaID}/${filmID}`);
  } else {
    router.push(`/cinemaInfo/${cinemaID}`);
  }
}
</script>

<template>
  <div class="body">
    <div class="dropdown">
      <el-dropdown>
        <span style="color: rgb(75 75 75)"> 排序▼</span>
        <template #dropdown>
          <el-dropdown-menu>
            <el-dropdown-item @click="getDistance('asc')"
              >从近到远</el-dropdown-item
            >
            <el-dropdown-item @click="getDistance('desc')"
              >从远到近</el-dropdown-item
            >
          </el-dropdown-menu>
        </template>
      </el-dropdown>
    </div>
    <div class="list">
      <ul class="infinite-list">
        <li
          v-for="(item, i) in cinemaInfo.data"
          :key="i"
          class="infinite-list-item"
          @click="toCinemaInfoView(item.id, filmInfo.data[i].id)"
        >
          <div class="h">
            <div class="title">{{ item.cinemaName }}</div>
            <div class="text">
              <div class="price">
                <span>{{ price(filmInfo.data[i]) }}</span
                >起
              </div>
              <div class="distance">
                <span>{{ distanceInit(item.distance) }}</span
                >km
              </div>
            </div>
          </div>
          <div class="tags">
            <el-tag class="ml-2" type="danger" size="small">
              限时特价票
            </el-tag>
            <el-tag size="small">可退票</el-tag>
            <el-tag size="small">可改签</el-tag>
            <el-tag type="info" size="small">观影小视</el-tag>
          </div>
        </li>
      </ul>
      <div class="load" @click="load">点击加载更多</div>
    </div>
  </div>
</template>

<style scoped>
.body {
  width: 100%;
  height: 100%;
  padding: 0 15px 10px;
  position: relative;
  background-color: rgb(248, 248, 248);
  border-top-left-radius: 16px;
  border-top-right-radius: 16px;
  /* flex: 1; */
  overflow-y: scroll;
}
.body .dropdown {
  margin-top: 8px;
}
.list {
  margin-top: 20px;
  /* min-height: 80vh; */
  min-height: 100px;
}

.list li {
  width: 100%;
  /* height: 100px; */
  background-color: white;
  border-radius: 12px;
  margin-bottom: 10px;
  padding: 18px 10px;
  display: flex;
  flex-direction: column;
}
.list li .h {
  display: flex;
  justify-content: space-between;
}
.list li .h .title {
  max-width: 80%;
  font-size: 18px;
  font-weight: 600;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.list li .h .text .price {
  font-size: 12px;
  text-align: right;
}
.list li .h .text .price span {
  font-size: 16px;
  margin-right: 5px;
  color: rgb(247, 91, 120);
  font-weight: 600;
}
.list li .h .text .distance {
  margin-top: 5px;
  font-size: 14px;
  text-align: right;
}
.list li .h .text .distance span {
  margin-right: 3px;
  text-align: right;
}
.list li .tags {
  margin-top: 10px;
}
.list li .tags span {
  margin-right: 5px;
}
.load {
  width: 100%;
  text-align: center;
  font-size: 12px;
  margin-top: 5px;
  color: deepskyblue;
}
</style>
