<script setup>
import { ref, reactive, defineProps } from "vue";
import voucher from "@/api/voucher/voucherApi.js";
import buy from "@/api/order/buy.js";
import { useRouter, useRoute } from "vue-router";

const route = useRoute();
const router = useRouter();

const props = defineProps({
  //子组件接收父组件传递过来的值

  cinemeID: String,
});
const voucherInfo = reactive({
  data: [],
});
voucher.getVoucherByFilmID(props.cinemeID).then((res) => {
  voucherInfo.data = res;
});
function buyVoucher(voucherID) {
  buy.buyVoucher(voucherID).then((res) => {
    router.push(`/bought/order/${res}`);
  });
}
</script>
<template>
  <div class="voucher">
    <div class="title">优惠券</div>
    <div class="list">
      <ul>
        <li v-for="(item, i) in voucherInfo.data" :key="i">
          <div class="head">
            <div class="title">{{ item.title }}</div>
            <div class="rule">{{ item.rule }}</div>
          </div>

          <div class="price">
            <el-button type="danger" size="small" @click="buyVoucher(item.id)"
              >{{ item.price }}元抢购</el-button
            >
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
ul > li {
  list-style: none;
  background-color: rgb(245, 245, 245);
  margin-bottom: 5px;
  padding: 5px 10px;
  border-radius: 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.list {
  margin-top: 10px;
  font-size: 14px;
}
.list .title {
  font-size: 18px;
  color: rgb(238, 48, 48);
}
.list .rule {
  font-size: 12px;
  color: rgb(196, 196, 196);
}
.list .price :deep(.el-button span) {
  font-size: 14px;
}
</style>
