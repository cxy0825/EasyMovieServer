<script setup>
import cinemaList from "@/views/cinema/cinemaList.vue";
import headerSearch from "@/components/headerSearch.vue";
// import { ref, reactive, onMounted, onActivated, computed } from "vue";
import { useRouter, useRoute } from "vue-router";
// import movieApi from "@/api/movie/movieApi.js";
// import movieSet from "@/api/movie/movieSet.js";
// import cinemaApi from "@/api/movie/cinemaApi.js";
// import { useMainStore } from "@/pinia/mainStore.js";

// const mainStore = useMainStore();
const route = useRoute();
</script>
<template>
  <div class="root">
    <headerSearch />
    <cinemaList :key="route.fullPath" />
  </div>
</template>

<style scoped>
.root {
  display: flex;
  flex-direction: column;
  overflow-y: scroll;
  flex: 1;
}
</style>
