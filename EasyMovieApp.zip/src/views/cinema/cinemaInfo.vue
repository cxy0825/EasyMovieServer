<script setup>
import voucher from "@/views/cinema/voucher.vue";
import pageHead from "@/components/pageHead.vue";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, onMounted, onActivated, computed } from "vue";
import cinemaApi from "@/api/movie/cinemaApi.js";
import movieApi from "@/api/movie/movieApi.js";
import movieSet from "@/api/movie/movieSet.js";

const route = useRoute();
const router = useRouter();
const cinemaID = route.params.cinemaID;
const filmID = route.params.filmID;
const cinemaInfo = reactive({
  data: {
    cinemaName: "鸡哥鸡哥鸡哥",
  },
});
const filmInfo = reactive({
  data: {
    posterUrls: [],
  },
});
const filmList = reactive({
  data: [],
});
const movieSetList = reactive({
  data: [],
});
//过滤出时间信息
const d = computed(() => {
  return (date) => {
    return date.slice(10, 16);
  };
});

//获取电影院信息
cinemaApi.getCinemaInfoByID(cinemaID).then((res) => {
  cinemaInfo.data = res;
});

//获取电影信息
if (filmID != undefined && filmID != "") {
  movieApi.getFilmINfoById(filmID).then((res) => {
    filmInfo.data = res;
  });
  //获取该电影今天的排片
  movieSet.getTodayInfo(cinemaID, filmID).then((res) => {
    movieSetList.data = res;
  });
}

//根据电影ID查询电影信息和获取排片时间
function getFilmInfo(filmID) {
  movieApi.getFilmINfoById(filmID).then((res) => {
    filmInfo.data = res;
  });
  //获取该电影今天的排片
  movieSet.getTodayInfo(cinemaID, filmID).then((res) => {
    //遍历获取电影放映厅信息
    res.forEach((item) => {
      movieApi.getMovueHouse(item.movieHouseId).then((r) => {
        item.movieHouseName = r.movieHouseName;
      });
    });

    movieSetList.data = res;
  });
}
//获取该电影院其他电影信息
movieApi.getFilmINfoList(cinemaID).then((res) => {
  filmList.data = res.records;
});

//去购票页面
function toBoughtView(movieSetId) {
  router.push(`/bought/movieSet/${movieSetId}`);
}
</script>
<template>
  <div class="root">
    <pageHead />
    <div class="head">
      <div class="bg">
        <img
          src="https://img1.baidu.com/it/u=1244570471,640091325&fm=253&fmt=auto&app=138&f=JPEG?w=919&h=500"
        />
      </div>
      <div class="text">
        <span class="title">{{ cinemaInfo.data.cinemaName }}</span>
        <br />
        <span class="tag"
          >好评度92% · 可改签 · 儿童优惠 · VIP优惠 · 观影小吃</span
        >
      </div>
    </div>
    <div class="body">
      <voucher :cinemeID="cinemaID" />
      <div class="img">
        <div class="one" v-if="filmInfo.data.posterUrls.length != 0">
          <img :src="filmInfo.data.posterUrls[0]" />
        </div>
        <div class="all">
          <el-scrollbar>
            <div class="scrollbar-flex-content">
              <img
                v-for="(item, i) in filmList.data"
                :src="item.posterUrls[0]"
                :key="i"
                class="scrollbar-demo-item"
                @click="getFilmInfo(item.id)"
              />
            </div>
          </el-scrollbar>
        </div>
      </div>
      <div class="detil" v-if="filmInfo.data.posterUrls.length != 0">
        <div class="title">{{ filmInfo.data.filmName }}</div>
        <div class="rate">{{ filmInfo.data.score / 2 }}分</div>
        <div class="tag">{{ filmInfo.data.tags.join(",") }}</div>
        <div class="t">{{ filmInfo.data.duration }}分钟</div>
      </div>
      <div class="movieSet" v-if="filmInfo.data.posterUrls.length != 0">
        <div
          class="movieSetItem"
          v-for="(item, i) in movieSetList.data"
          :key="i"
        >
          <div class="time">
            <div class="start">{{ d(item.movieStartTime) }}</div>
            <div class="end">{{ d(item.movieEndTime) }}离场</div>
          </div>
          <div class="moviehouse">
            {{ item.movieHouseName }}
          </div>
          <div class="price">￥{{ item.price }}</div>
          <div class="btn">
            <el-button type="danger" size="small" @click="toBoughtView(item.id)"
              >购票</el-button
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.root {
  width: 100vw;
  min-height: 100vh;
}
.root .head {
  width: 100vw;
  height: 400px;
  position: relative;
  display: flex;
  align-items: flex-end;
}
.root .head .bg {
  width: 100%;
  height: 100%;
  overflow: hidden;
  position: absolute;
  z-index: -1;
}
.root .head .bg img {
  /* height: 100%; */
  object-fit: cover;
}
.root .head .text {
  width: 100%;
  color: white;
  padding: 0 10px 60px;
}
.root .head .text .title {
  font-weight: 600;
  font-size: 16px;
}
.root .head .text .tag {
  font-size: 12px;
  color: rgb(196, 196, 196);
}
.root .body {
  width: 100%;
  min-height: 400px;
  border-top-left-radius: 24px;
  border-top-right-radius: 24px;
  background-color: rgb(255, 255, 255);
  position: relative;
  transform: translateY(-45px);
  padding: 20px 15px 0;
}
.root .body .img {
  width: 100%;
  margin-top: 15px;
  display: flex;
  flex-direction: row;
}
.root .body .img .one {
  width: 120px;
}
.root .body .img .all {
  flex: 1;
  overflow: auto;
  margin-left: 5px;
}
.root .body .img .all .scrollbar-flex-content {
  display: flex;
}
.root .body .img .all .scrollbar-demo-item {
  width: 120px;
  margin-right: 5px;
}
.root .body .img img {
  width: 100%;
  border-radius: 8px;
}
.root .body .detil {
  width: 100;
  margin: 10px auto 10px;
  background-color: rgb(235, 235, 235);
  border-radius: 8px;
  padding: 10px 15px;
}
.root .body .detil > div {
  margin-bottom: 5px;
}
.root .body .detil .title {
  width: 100%;
  font-size: 16px;
  font-weight: 600;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.root .body .detil .rate {
  color: coral;
  font-size: 13px;
}
.root .body .detil .tag {
  font-size: 13px;
  color: rgb(145, 149, 150);
}
.root .body .detil .t {
  font-size: 13px;
  color: rgb(145, 149, 150);
}
.root .body .movieSet {
  width: 100%;
  height: 400px;
  padding: 0 15px;
  overflow: auto;
  margin-top: 20px;
}
.root .body .movieSet .movieSetItem {
  border-bottom: 1px solid rgb(204, 204, 204);
  padding-bottom: 10px;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.root .body .movieSet .movieSetItem .time {
  width: 60px;
}
.root .body .movieSet .movieSetItem .time .start {
  font-size: 18px;
  font-weight: 600;
  text-align: center;
}
.root .body .movieSet .movieSetItem .time .end {
  font-size: 13px;
  text-align: center;
}
.root .body .movieSet .movieSetItem .moviehouse {
  width: 120px;
  font-size: 14px;
  text-align: center;
}
.root .body .movieSet .movieSetItem .price {
  font-size: 20px;
  color: crimson;
  font-weight: 600;
}
</style>
