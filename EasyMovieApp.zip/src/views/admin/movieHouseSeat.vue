<script setup>
import seatInfo from "@/components/seatInfo.vue";
import { ref, reactive } from "vue";
import { useRouter, useRoute } from "vue-router";
const router = useRouter();
const route = useRoute();
const movieHouseID = route.params.id;
const subData = ref([]);
//子组件传递事件
const change = function (data) {
  subData.value = data;
};
</script>
<template>
  <div class="seat">
    <seatInfo :movieHouseID="movieHouseID" class="seatInfo" @change="change" />
  </div>
</template>

<style scoped>
.seat {
  width: 100%;

  display: flex;
  flex-direction: column;
}
.btns {
  width: 100%;

  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
  margin-bottom: 10px;
}
</style>
