<script setup>
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import tag from "@/api/tag/tag.js";
const router = useRouter();
const input = ref("");
const tagList = ref([]);
tag.getTagList(1, 12).then((res) => {
  tagList.value = res.records;
});
function rgb() {
  //rgb颜色随机
  const r = Math.floor(Math.random() * 256);
  const g = Math.floor(Math.random() * 256);
  const b = Math.floor(Math.random() * 256);
  return `rgb(${r},${g},${b})`;
}
function search() {
  router.push(`/admin/main/tag/list/${input.value}`);
}
function to(tagName) {
  router.push(`/admin/main/tag/list/${tagName}`);
}

//获取标签
</script>
<template>
  <div class="search">
    <div class="title">搜索你想要的标签</div>
    <div class="input">
      <el-input v-model="input" placeholder="输入你想要的标签" />
      <el-button type="primary" @click="search">搜索</el-button>
    </div>
    <el-row :gutter="20" class="show">
      <el-col
        :span="6"
        :style="{ color: rgb() }"
        v-for="(item, index) in tagList"
        :key="index"
        @click="to(item.tagName)"
      >
        {{ item.tagName }}
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.search {
  width: 80%;
  height: 500px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}
.search .title {
  font-size: 16px;
  margin-bottom: 40px;
}
.search .input {
  display: flex;
  width: 100%;
  justify-content: space-around;
}
.search .input .el-input {
  width: 500px;
}
.search .input .el-button {
  margin-left: 10px;
  border-radius: 20px;
}

.search .input >>> .el-input__wrapper {
  border-radius: 20px;
}
.search .input >>> input {
  width: 500px;
  border-radius: 20px;
  height: 31px;
  padding-top: 8px;
  padding-bottom: 8px;
}
.search .show {
  width: 100%;
  margin-top: 18px;
  font-size: 14px;
}
.search .show > div {
  text-decoration: underline;
  cursor: pointer;
  margin-bottom: 18px;
}
.search .show > div:hover {
  color: rgb(253, 53, 53);
  font-weight: 600;
}
</style>
