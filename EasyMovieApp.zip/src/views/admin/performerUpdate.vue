<script setup>
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, toRefs, isReactive } from "vue";
import movie from "@/api/movie/movieApi.js";
import performer from "@/api/movie/performerApi.js";
import tag from "@/api/tag/tag.js";
import { ElMessage, ElLoading } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
const router = useRouter();
const route = useRoute();
const id = route.params.id;
const mainStore = useMainStore();

let title = ref("添加演员信息");

//上传组件
const uploadRef = ref();
//基本信息
const performerInfo = reactive({
  data: {},
});
//如果没有接收到ID说明是添加,那么就不需要获取数据
if (id != undefined || id != null) {
  //   拿到id后获取根据这个id获取详情;
  performer.getPerformerInfo(id).then((res) => {
    performerInfo.data = res;
    title.value =
      "修改 「 " + performerInfo.data.performerName + " 」 演员信息";
  });
}

//上传图片
function submitUpload() {
  let formData = new FormData();
  formData.append("uploadFile", uploadRef.value.files[0]);
  performer.upload(id, formData).then((res) => {
    performerInfo.data.performerPicUrl = res;
  });
}

//提交
const onSubmit = function () {
  const loadingInstance = ElLoading.service({ target: "#updataView" });
  performer
    .update(performerInfo.data)
    .then((res) => {
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      });

      router.push("/admin/main/performer/info");
    })
    .finally(() => {
      loadingInstance.close();
    });
};
//取消
const cancel = function () {
  router.push("/admin/main/performer/info");
};
</script>
<template>
  <div id="updataView" style="position: relative">
    <div class="title" style="position: absolute; top: 40px; left: 80px">
      {{ title }}
    </div>
    <el-form
      ref="ruleFormRef"
      label-position="top"
      label-width="100px"
      :model="performerInfo.data"
    >
      <el-form-item label="演员ID:" v-if="performerInfo.data.id != null">
        <el-input
          v-model="performerInfo.data.id"
          :disabled="true"
          style="width: 120px"
        />
      </el-form-item>
      <el-form-item label="演员名字:">
        <el-input
          v-model="performerInfo.data.performerName"
          style="min-width: 200px"
        />
      </el-form-item>
      <el-input
        v-model="performerInfo.data.performerAbout"
        :rows="5"
        type="textarea"
        placeholder="演员的简介信息"
      />
      <el-form-item label="演员图片:" v-if="id != undefined">
        <el-image
          style="width: 100px; height: 100px"
          :src="performerInfo.data.performerPicUrl"
          :preview-src-list="[performerInfo.data.performerPicUrl]"
          fit="cover"
        />

        <div class="upload">
          <label>
            <div class="btn">选择图片</div>
            <input type="file" ref="uploadRef" />
          </label>

          <el-button @click="submitUpload" style="margin-left: 20px"
            >上传</el-button
          >
        </div>
      </el-form-item>
      <el-form-item label="演员生日">
        <el-date-picker
          v-model="performerInfo.data.birthday"
          type="date"
          placeholder="选择时间"
          value-format="YYYY年MM月DD日"
        />
      </el-form-item>
      <el-form-item class="btnGroup">
        <el-button type="primary" @click="onSubmit">提交修改</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>
#updataView {
  width: 96%;
  /* margin-top: 400px; */
}
#updataView :deep(.el-form-icon) {
  position: relative;
}
.title {
  margin-bottom: 10px;
}
.el-form {
  /* height: 90%; */
  padding: 80px;
}

.btnGroup {
  margin-top: 30px;
}
.el-image >>> .el-icon {
  position: relative;
}
.tag {
  margin-top: 20px;
  display: flex;
  flex-direction: column;
}
.tag >>> .el-icon {
  position: relative;
}
.tag >>> .el-form-item__content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.tagSelect {
  display: flex;
  flex-direction: row;
  margin-bottom: 10px;
}
.tagSelect .title {
  margin: 0 20px 0 0px;
}
.upload {
  width: 250px;
}
.upload input {
  display: none;
}
.upload .btn {
  width: 60px;
  height: 30px;
  border-radius: 6px;
  background-color: rgb(38, 175, 255);
  text-align: center;
  color: white;
  cursor: pointer;
  margin-left: 20px;
  font-size: 13px;
}
.video {
  width: 300px;
  height: 200px;
  overflow: hidden;
}
.video video {
  width: 100%;
  height: 100%;
}
</style>
