<script setup>
import administrator from "@/api/users/Administrator";
import { useRouter } from "vue-router";
import { reactive, ref } from "vue";
import { ElMessage } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
import { storeToRefs } from "pinia";
const mainStore = useMainStore();
let { userId, cinemaId, name, account, power } = storeToRefs(mainStore);
const router = useRouter();
//表单校验
const FormDate = reactive({
  account: "",
  password: "",
});
const rules = reactive({
  account: [
    { required: true, message: "必须输入账号", trigger: "change" },
    {
      pattern: /^[a-z0-9]{3,20}$/,
      message: "账号长度不正确",
      trigger: "change",
    },
  ],
  password: [
    { required: true, message: "必须输入密码", trigger: "change" },
    {
      pattern: /^[a-z0-9]{3,20}$/,
      message: "密码长度不正确",
      trigger: "change",
    },
  ],
});
const ruleFormRef = ref();
//登录
const login = function (ruleFormRef) {
  if (!ruleFormRef) return;
  //表单校验
  // 只有通过才进行登录请求
  ruleFormRef.validate((validate, fields) => {
    if (validate) {
      administrator
        .login({
          account: FormDate.account,
          password: FormDate.password,
        })
        .then((res) => {
          //提示
          ElMessage({
            showClose: true,
            message: "登录成功",
            type: "success",
          });
          //把 token写入localhost中
          localStorage.setItem("token", res);
        })
        .then(() => {
          // 登录后获得账号信息
          return administrator.getInfo();
        })
        .then((res) => {
          console.log(res);

          //把相关信息写入到pinia中
          mainStore.userId = res.id;
          mainStore.cinemaId = res.cinemaId;
          mainStore.name = res.name;
          mainStore.account = res.account;
          mainStore.type = res.type;
          mainStore.avatarUrl = res.avatarUrl;
          mainStore.power = res.power;
          router.push("/admin/main/movieHouse/Info");
        });
    }
  });
};
</script>
<template>
  <el-row :gutter="0" style="height: 100vh">
    <el-col :span="16">
      <div class="img">
        <img src="@/assets/static/img/background1.png" alt="" />
      </div>
    </el-col>
    <el-col :span="8" style="height: 100vh" class="form">
      <!-- <div class="title">EM电影后台管理</div> -->
      <div class="title">基金系统登陆</div>
      <el-form
        ref="ruleFormRef"
        :model="FormDate"
        status-icon
        :rules="rules"
        label-width="60px"
        hide-required-asterisk
      >
        <el-form-item label="账号" prop="account">
          <el-input v-model="FormDate.account" type="text" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="FormDate.password"
            type="password"
            autocomplete="off"
          />
        </el-form-item>
        <el-button type="primary" @click="login(ruleFormRef)" class="login"
          >登录</el-button
        >
      </el-form>
    </el-col>
  </el-row>
</template>

<style scoped>
.img {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.el-row {
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
}
.el-col {
  width: 100%;
  height: 100%;
}
.form {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.form form {
  width: 80%;
  display: flex;
  flex-direction: column;
}
.title {
  margin-bottom: 50px;
  width: 100%;
  text-align: center;
  font-size: 26px;
  font-weight: 600;
}
.form button {
  margin-top: 20px;
  width: 50%;
  height: 40px;
  margin: 0 auto;
  border-radius: 20px;
}
</style>
