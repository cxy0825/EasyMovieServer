<script setup>
import { ref, reactive, isReactive, watch } from "vue";
import { useRouter, useRoute } from "vue-router";
import { useMainStore } from "@/pinia/mainStore.js";
import { storeToRefs } from "pinia";
import { ElMessage, ElMessageBox } from "element-plus";
import performer from "@/api/movie/performerApi.js";
const mainStore = useMainStore();
const router = useRouter();
// const route = useRoute();
// console.log(route);
// let { power } = storeToRefs(mainStore);
let tableData = reactive({ page: {} });
//抽离获取数据方法
const getTableData = function (page = 1, size = 10, name = null) {
  performer.getPerformInfoList(page, size, name).then((res) => {
    tableData.page = res;
  });
};
//获取数据
getTableData();

//多选的表格dom
const multipleTableRef = ref();

//点击查看按钮
const infoById = function (id) {
  router.push(`/admin/main/movieHouse/seatInfo/${id}`);
};
//点击删除按钮
const removeById = function (id) {
  //弹出提示框
  ElMessageBox.confirm("你确定要吗?", "警告", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
  })
    //发送请求
    .then(() => {
      performer
        .del(id)
        //重新获取
        .then(() => {
          //隐藏按钮
          batchType.value = "primary";
          buttonActive.value = false;
          batch.value = "批量操作";
          //重新获取一次数据
          getTableData();
        });
    })
    .catch();
};
//点击更改按钮
// 跳转到更改的表格
const updateById = function (id) {
  router.push(`/admin/main/performer/update/${id}`);
};
//根据演员名字筛选
let name = ref("");
const searchByName = function () {
  if (name.value.trim() != "") {
    getTableData(1, 10, name.value.trim());
  } else {
    getTableData();
  }
};
//批量操作
const batch = ref("批量操作");
const buttonActive = ref(false);
const batchType = ref("primary");
const batchFunction = function () {
  if (batch.value == "批量操作") {
    //显示按钮和多选
    batchType.value = "danger";
    buttonActive.value = true;
    batch.value = "取消";
  } else if (batch.value == "取消") {
    //隐藏按钮
    batchType.value = "primary";
    buttonActive.value = false;
    batch.value = "批量操作";
  }
};

//批量删除
const batchDel = function () {
  //弹出提示框
  //弹出提示框
  ElMessageBox.confirm("你确定要批量删除这些吗?", "警告", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
  })
    //发送请求
    .then(() => {
      let selectionRows = multipleTableRef.value.getSelectionRows();
      for (let row of selectionRows) {
        performer.del(id)(row.id);
      }
    })
    //重新获取列表
    .then(() => {
      //隐藏按钮
      batchType.value = "primary";
      buttonActive.value = false;
      batch.value = "批量操作";
      //重新获取一次数据
      getTableData();
    })
    .catch();
};

//分页

//当前是第几页
let currentPage = ref(1);
//页数改变就重新获取
watch(currentPage, (newValue, oldValue) => {
  getTableData(newValue);
});
</script>
<template>
  <div class="movieContainer">
    <div class="h">
      <div class="search">
        <el-input v-model="name" placeholder="根据放映厅名字查询" />
        <el-button type="primary" @click="searchByName">搜索</el-button>
      </div>
      <div class="buttons">
        <el-button :type="batchType" @click="batchFunction">
          {{ batch }}
        </el-button>

        <el-button type="primary" @click="batchDel" v-show="buttonActive"
          >批量删除</el-button
        >
      </div>
    </div>

    <div class="table">
      <el-table
        ref="multipleTableRef"
        :data="tableData.page.records"
        stripe
        show-header
        highlight-current-row
        height="100%"
        style="width: 100%"
      >
        <el-table-column type="selection" width="55" v-if="buttonActive" />
        <el-table-column prop="id" label="ID" width="60" />
        <el-table-column prop="performerName" label="演员名字" />
        <el-table-column
          prop="performerAbout"
          label="简介"
          show-overflow-tooltip
        />
        <el-table-column label="操作" width="300">
          <template #default="scope">
            <el-button type="primary" plain @click="updateById(scope.row.id)"
              >更改</el-button
            >
            <el-button type="danger" plain @click="removeById(scope.row.id)"
              >删除</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="page">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="tableData.page.pages * 10"
        next-text="下一页"
        prev-text="上一页"
        v-model:currentPage="currentPage"
      />
    </div>
  </div>
</template>

<style>
.movieContainer {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
}
.h {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.search {
  width: 300px;
  display: flex;
  justify-self: center;
  align-items: center;
}
.search .el-input {
  width: 200px;
  margin: 5px 10px;
}
.table {
  width: 100%;
  height: 450px;
  display: flex;
  overflow-y: scroll;
  flex: 1 1 auto;
}
.table .el-table__row--striped {
  background: #f3f3f3;
}
.table .cell {
  color: #000;
  text-align: center;
}
.page {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 10px;
  height: 50px;
}
.page .el-icon {
  position: relative;
}
</style>
