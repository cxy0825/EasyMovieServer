<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useMainStore } from "@/pinia/mainStore.js";
const mainStore = useMainStore();
const router = useRouter();
</script>
<template>
  <div class="my-collapse">
    <div class="userInfo">
      <div class="name">你好: {{ mainStore.name }}</div>
    </div>
    <el-menu
      :default-active="router.currentRoute.value.path"
      router
      class="el-menu-vertical-demo"
    >
      <el-sub-menu index="1">
        <template #title>
          <span>首页</span>
        </template>
        <el-menu-item index="/admin/main">
          <template #title>首页展示</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/admin/main/movieHouse">
        <template #title>
          <span>放映厅管理</span>
        </template>
        <el-menu-item
          index="/admin/main/movieHouse/Info"
          router="/admin/main/movieHouse/Info"
        >
          <template #title>放映厅列表</template>
        </el-menu-item>
        <el-menu-item
          index="/admin/main/movieHouse/add"
          router="/admin/main/movieHouse/add"
        >
          <template #title>增加放映厅</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/admin/main/tag">
        <template #title>
          <span>电影标签管理</span>
        </template>
        <el-menu-item
          index="/admin/main/tag/search"
          router="/admin/main/tag/search"
        >
          <template #title>标签查询</template>
        </el-menu-item>
        <el-menu-item index="/admin/main/tag/add" router="/admin/main/tag/add">
          <template #title>添加标签</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/admin/main/film">
        <template #title>
          <span>电影信息管理</span>
        </template>
        <el-menu-item
          index="/admin/main/film/info"
          router="/admin/main/film/info"
        >
          <template #title>电影信息列表</template>
        </el-menu-item>
        <el-menu-item
          index="/admin/main/film/add"
          router="/admin/main/film/add"
        >
          <template #title>添加信息</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/admin/main/performer">
        <template #title>
          <span>演员信息</span>
        </template>
        <el-menu-item
          index="/admin/main/performer/info"
          router="/admin/main/performer/info"
        >
          <template #title>演员管理</template>
        </el-menu-item>
        <el-menu-item
          index="/admin/main/performer/add"
          router="/admin/main/performer/add"
        >
          <template #title>添加演员</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/admin/main/movieSet">
        <template #title>
          <span>排片管理</span>
        </template>
        <el-menu-item
          index="/admin/main/movieSet/info"
          router="/admin/main/movieSet/info"
        >
          <template #title>电影信息列表</template>
        </el-menu-item>
        <el-menu-item
          index="/admin/main/movieSet/add"
          router="/admin/main/movieSet/add"
        >
          <template #title>添加排片</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/admin/main/voucher">
        <template #title>
          <span>优惠券管理</span>
        </template>
        <el-menu-item
          index="/admin/main/voucher/info"
          router="/admin/main/voucher/info"
        >
          <template #title>优惠券列表</template>
        </el-menu-item>
        <el-menu-item
          index="/admin/main/voucher/add"
          router="/admin/main/voucher/add"
        >
          <template #title>添加优惠券</template>
        </el-menu-item>
      </el-sub-menu>
    </el-menu>
  </div>
</template>

<style>
.userInfo {
  width: 100%;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: darkgrey;
  font-size: 14px;
}
.my-collapse {
  width: 100%;
}
.my-collapse .el-collapse-item__header {
  width: 100%;
  text-align: center;
  font-size: 14px;
  display: flex;
  justify-content: center;
  position: relative;
}
.el-icon {
  position: absolute;
  right: 0;
}
.my-collapse .item {
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  color: #a1a1a1;
}
.my-collapse .item.active {
  background: #3f82ff;
  color: #fff;
}
.my-collapse .item:hover {
  background: #3f82ff;
  color: #fff;
}
.my-collapse .item span {
  text-decoration: none;

  font-size: 14px;
}
</style>
