<script setup>
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, toRefs, isReactive } from "vue";
import movie from "@/api/movie/movieApi.js";
import { ElMessage, ElLoading } from "element-plus";

const router = useRouter();
const route = useRoute();
const id = route.params.id;
// defineProps({
//   id: {
//     type: String,
//     default: "1",
//   },
// });
let movieHouseInfo = reactive({
  data: {},
});
let title = ref("添加放映厅");
//如果没有接收到ID说明是添加,那么就不需要获取数据
if (id != undefined || id != null) {
  //   拿到id后获取根据这个id获取详情;
  movie.getMovueHouseInfoByID(id).then((res) => {
    movieHouseInfo.data = res;
    title.value =
      "修改 「 " + movieHouseInfo.data.movieHouseName + " 」 放映厅信息";
  });
}
//提交
const onSubmit = function () {
  const loadingInstance = ElLoading.service({ target: "#updataView" });
  movie
    .updateMoveHouse(movieHouseInfo.data)
    .then((res) => {
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      });

      router.push("/admin/main/movieHouse/info");
    })
    .finally(() => {
      loadingInstance.close();
    });
};
//取消
const cancel = function () {
  router.push("/admin/main/movieHouse/info");
};
</script>

<template>
  <div id="updataView" style="position: relative">
    <div class="title" style="position: absolute; top: 40px; left: 80px">
      {{ title }}
    </div>
    <el-form
      ref="ruleFormRef"
      label-position="top"
      label-width="100px"
      :model="movieHouseInfo.data"
    >
      <el-form-item label="放映厅ID:">
        <el-input
          v-model="movieHouseInfo.data.id"
          :disabled="true"
          style="width: 120px"
        />
      </el-form-item>
      <el-form-item label="放映厅名字:">
        <el-input
          v-model="movieHouseInfo.data.movieHouseName"
          style="width: 300px"
        />
      </el-form-item>

      <el-form-item label="放映厅状态:">
        <el-switch
          :active-value="1"
          :inactive-value="0"
          active-text="启用"
          inactive-text="禁用"
          v-model="movieHouseInfo.data.state"
        />
      </el-form-item>

      <div class="group">
        <el-form-item label="排数量:(每一列的座位数量)">
          <el-input v-model="movieHouseInfo.data.rowNum" style="width: 100px" />
        </el-form-item>
        <el-form-item label="列数量:(每一排的座位数量)">
          <el-input v-model="movieHouseInfo.data.colNum" style="width: 100px" />
        </el-form-item>
      </div>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">提交修改</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>
.el-form {
  width: 90%;
  height: 90%;
  padding: 80px 150px;
}
.el-form-item {
  margin-bottom: 35px;
}
.group {
  display: flex;
  justify-content: space-between;
}
#updataView :deep(.el-form-icon) {
  position: relative;
}
</style>
