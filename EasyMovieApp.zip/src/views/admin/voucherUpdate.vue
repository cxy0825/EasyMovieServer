<script setup>
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, toRefs, isReactive } from "vue";
import voucher from "@/api/voucher/voucherApi.js";
import { ElMessage, ElLoading } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
const router = useRouter();
const route = useRoute();
const id = route.params.id;
const mainStore = useMainStore();
//电影院ID

let voucherInfo = reactive({
  data: {
    id: null,
    cinemaId: mainStore.cinemaId,
    cinemaName: null,
    title: null,
    rule: null,
    payValue: null,
    actualValue: null,
    price: null,
    state: 1,
    stock: null,
    startTime: null,
    endTime: null,
  },
});
let title = ref("添加电影院优惠券");

//时间组件
const time = ref([]);

//如果没有接收到ID说明是添加,那么就不需要获取数据
if (id != undefined || id != null) {
  voucher.getVoucherInfo(1, 1, { id: id }).then((res) => {
    voucherInfo.data = res.records[0];
    //因为时间组件绑定的是time这个变量所以要额外赋值
    time.value.push(res.records[0].startTime);
    time.value.push(res.records[0].endTime);
  });
}
//更改了时间
function tiemChange(value) {
  voucherInfo.data.startTime = value[0];
  voucherInfo.data.endTime = value[1];
}
//提交
const onSubmit = function () {
  const loadingInstance = ElLoading.service({ target: "#updataView" });
  voucher
    .updatedVoucher(voucherInfo.data)
    .then((res) => {
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      });
      router.push("/admin/main/voucher/info");
    })
    .finally(() => {
      loadingInstance.close();
    });
};
//取消
const cancel = function () {
  router.push("/admin/main/voucher/info");
};
</script>
<template>
  <div id="updataView" style="position: relative">
    <div class="title" style="position: absolute; top: 40px; left: 80px">
      {{ title }}
    </div>
    <el-form ref="ruleFormRef" label-position="top" label-width="100px">
      <el-form-item label="优惠券标题" style="width: 400px">
        <el-input
          v-model="voucherInfo.data.title"
          placeholder="请输入优惠券标题"
        />
      </el-form-item>
      <el-form-item label="优惠券规则" style="width: 300px">
        <el-input
          v-model="voucherInfo.data.rule"
          placeholder="请输入优惠券使用规则"
        />
      </el-form-item>
      <el-form-item label="优惠券使用门槛(元)" style="width: 300px">
        <el-input-number
          v-model="voucherInfo.data.payValue"
          placeholder="请输入优惠券使用门槛"
        />
      </el-form-item>
      <el-form-item label="优惠券减免金额(元)" style="width: 300px">
        <el-input-number
          v-model="voucherInfo.data.actualValue"
          placeholder="请输入优惠券减免金额"
        />
      </el-form-item>
      <el-form-item label="优惠券价格(元)" style="width: 300px">
        <el-input-number
          v-model="voucherInfo.data.price"
          placeholder="请输入优惠券价格"
        />
      </el-form-item>
      <el-form-item label="优惠券数量" style="width: 200px">
        <el-input
          v-model="voucherInfo.data.stock"
          placeholder="请输入优惠券数量"
        />
      </el-form-item>
      <el-form-item label="优惠券状态" style="width: 200px">
        <el-switch
          v-model="voucherInfo.data.state"
          size="large"
          active-text="启用"
          inactive-text="禁用"
          :active-value="1"
          :inactive-value="0"
        />
      </el-form-item>
      <el-form-item label="使用开始时间-使用结束时间:" style="width: 500px">
        <el-date-picker
          v-model="time"
          type="datetimerange"
          range-separator="-"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          value-format="YYYY-MM-DD HH:mm:ss"
          @change="tiemChange"
        />
      </el-form-item>
      <el-form-item class="btnGroup">
        <el-button type="primary" @click="onSubmit">提交修改</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>
#updataView {
  width: 96%;
  margin-top: 50px;
}
#updataView >>> .el-icon {
  position: relative;
}
.title {
  margin-bottom: 10px;
}
.el-form {
  /* height: 90%; */
  padding: 80px;
}

.btnGroup {
  margin-top: 30px;
  display: flex;
  justify-content: center;
}
.btnGroup >>> .el-form-item__content {
  justify-content: center;
}
.el-input-number {
  width: 300px;
}
</style>
