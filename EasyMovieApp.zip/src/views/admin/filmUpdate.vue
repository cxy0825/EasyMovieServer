<script setup>
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, toRefs, isReactive } from "vue";
import movie from "@/api/movie/movieApi.js";
import tag from "@/api/tag/tag.js";
import performer from "@/api/movie/performerApi.js";
import { ElMessage, ElLoading } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
const router = useRouter();
const route = useRoute();
const id = route.params.id;
const mainStore = useMainStore();

let filmInfo = reactive({
  data: {
    posterUrls: [],
    videoUrls: [],
    cinemaId: mainStore.cinemaId,
  },
});

let title = ref("添加电影信息");
let defaultTagList = ref([]);
//标签列表
let tagValue = ref("");

let performerInfo = reactive({
  data: {},
});
//演员列表
let performerValue = ref("");
let defaultPerformerList = ref([]);
let performerList = ref([]);
//上传组件
const uploadRef = ref();
const uploadRef2 = ref();
// //时间组件
// const time = ref([
//   new Date(2022, 10, 10, 10, 10),
//   new Date(2022, 10, 11, 10, 10),
// ]);

//如果没有接收到ID说明是添加,那么就不需要获取数据
if (id != undefined || id != null) {
  //   拿到id后获取根据这个id获取详情;
  movie.getFilmINfoById(id).then((res) => {
    filmInfo.data = res;
    title.value = "修改 「 " + filmInfo.data.filmName + " 」 电影信息";
  });
  //获取演员信息
  performer.getPerformers(id).then((res) => {
    performerList.value = res;
  });
}
//先获取到默认的标签列表

tag.getTagList().then((res) => {
  for (let tag of res.records) {
    defaultTagList.value.push(tag.tagName);
  }
});

//远程获取标签事件
function remoteMethod(query) {
  if (query) {
    tag.getTagInfoByName(query).then((res) => {
      console.log(res);
      //清空原先的数据
      defaultTagList.value.length = 0;
      for (let tag of res) {
        //加入数据
        defaultTagList.value.push(tag.tagName);
      }
    });
  } else {
    //如果值是空的就获取默认的标签组
    tag.getTagList().then((res) => {
      defaultTagList.value.length = 0;
      for (let tag of res.records) {
        defaultTagList.value.push(tag.tagName);
      }
    });
  }
}
//添加标签事件
async function change(value) {
  tag
    .getTagInfoByName(value)
    //获取ID
    .then((res) => {
      if (res.length == 0) {
        ElMessage({
          message: "添加标签失败",
          type: "warning",
        });
      }
      return res[0].id;
    })
    //添加ID
    .then((tagID) => {
      tag.addTag(id, tagID);
      return tagID;
    })
    //刷新tag列表
    .then(() => {
      setTimeout(() => {
        movie.getFilmINfoById(id).then((res) => {
          filmInfo.data = res;
        });
      }, 500);
    });
}
//移除标签事件
function tagClose(item, index) {
  //先通过名称获取id
  tag
    .getTagInfoByName(item)
    .then((res) => {
      return res[0].id;
    })
    .then((tagID) => {
      tag.delTag(id, tagID);
    }); //调用删除电影标签的接口

  //返回信息
  filmInfo.data.tags.splice(index, 1);
}
//移除电影演员事件
function performerClose(performerId) {
  performer.delIndex(id, performerId).then((res) => {
    //重新获取数据
    performer.getPerformers(id).then((res) => {
      performerList.value = res;
    });
  });
}
//远程获取演员事件
function remoteMethod2(query) {
  if (query) {
    //获取演员信息
    performer.getPerformInfoList(1, 10, query).then((res) => {
      defaultPerformerList.value = res.records;
    });
    // tag.getTagInfoByName(query).then((res) => {
    //   console.log(res);
    //   //清空原先的数据
    //   defaultTagList.value.length = 0;
    //   for (let tag of res) {
    //     //加入数据
    //     defaultTagList.value.push(tag.tagName);
    //   }
    // });
  }
}
//添加演员
async function change2(value) {
  performer.addPerformer(id, value).then((res) => {
    //获取演员信息
    performer.getPerformers(id).then((res) => {
      performerList.value = res;
    });
  });
}
//上传海报
function submitUpload() {
  let formData = new FormData();
  formData.append("uploadFile", uploadRef.value.files[0]);
  movie.addPoster(id, formData).then((res) => {
    filmInfo.data.posterUrls[0] = res;
  });
}
//上传视频
function submitUpload2() {
  let formData = new FormData();
  formData.append("uploadFile", uploadRef2.value.files[0]);
  movie.addVideo(id, formData).then((res) => {
    filmInfo.data.videoUrls[0] = res;
  });
}

//提交
const onSubmit = function () {
  const loadingInstance = ElLoading.service({ target: "#updataView" });
  movie
    .updateMovieInfo(filmInfo.data)
    .then((res) => {
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      });

      router.push("/admin/main/film/info");
    })
    .finally(() => {
      loadingInstance.close();
    });
};
//取消
const cancel = function () {
  router.push("/admin/main/film/info");
};
</script>
<template>
  <div id="updataView" style="position: relative">
    <div class="title" style="position: absolute; top: 40px; left: 80px">
      {{ title }}
    </div>
    <el-form
      ref="ruleFormRef"
      label-position="top"
      label-width="100px"
      :model="filmInfo.data"
    >
      <el-form-item label="电影ID:">
        <el-input
          v-model="filmInfo.data.id"
          :disabled="true"
          style="width: 120px"
        />
      </el-form-item>
      <el-form-item label="电影名字:">
        <el-input v-model="filmInfo.data.filmName" style="min-width: 200px" />
      </el-form-item>
      <el-input
        v-model="filmInfo.data.about"
        :rows="5"
        type="textarea"
        placeholder="电影的简介信息"
      />
      <el-form-item label="电影标签:" class="tag" v-if="id != undefined">
        <div class="tagSelect">
          <div class="title">添加标签</div>
          <el-select
            v-model="tagValue"
            filterable
            remote
            reserve-keyword
            placeholder="输入标签名"
            :remote-method="remoteMethod"
            class="select"
            @change="change"
          >
            <el-option
              v-for="item in defaultTagList"
              :key="item"
              :value="item"
            />
          </el-select>
        </div>
        <div class="tagContainer">
          <el-tag
            v-for="(item, index) in filmInfo.data.tags"
            :key="index"
            class="mx-1"
            closable
            style="margin-right: 10px; margin-bottom: 10px"
            @close="tagClose(item, index)"
          >
            {{ item }}
          </el-tag>
        </div>
      </el-form-item>
      <el-form-item label="演员列表:" class="tag" v-if="id != undefined">
        <div class="tagSelect">
          <div class="title">添加标签</div>
          <el-select
            v-model="performerValue"
            filterable
            remote
            reserve-keyword
            placeholder="输入演员名"
            :remote-method="remoteMethod2"
            class="select"
            @change="change2"
          >
            <el-option
              v-for="item in defaultPerformerList"
              :key="item"
              :value="item.id"
              :label="item.performerName"
            />
          </el-select>
        </div>
        <div class="tagContainer">
          <el-tag
            v-for="(item, index) in performerList"
            :key="index"
            class="mx-1"
            closable
            style="margin-right: 10px; margin-bottom: 10px"
            @close="performerClose(item.id)"
          >
            {{ item.performerName }}
          </el-tag>
        </div>
      </el-form-item>
      <el-form-item label="电影海报:" v-if="id != undefined">
        <el-image
          style="width: 100px; height: 100px"
          :src="filmInfo.data.posterUrls[0]"
          :preview-src-list="filmInfo.data.posterUrls"
          fit="cover"
        />

        <div class="upload">
          <label>
            <div class="btn">选择图片</div>
            <input type="file" ref="uploadRef" />
          </label>

          <el-button @click="submitUpload" style="margin-left: 20px"
            >上传</el-button
          >
        </div>
      </el-form-item>
      <el-form-item label="电影宣传片:" v-if="id != undefined">
        <div class="video">
          <video controls autoplay v-if="filmInfo.data.videoUrls[0]">
            <source :src="filmInfo.data.videoUrls[0]" type="video/mp4" />
          </video>
        </div>

        <div class="upload">
          <label>
            <div class="btn">选择视频</div>
            <input type="file" ref="uploadRef2" />
          </label>

          <el-button @click="submitUpload2" style="margin-left: 20px"
            >上传</el-button
          >
        </div>
      </el-form-item>
      <el-form-item label="电影时长(分钟):">
        <el-input v-model="filmInfo.data.duration" style="width: 200px" />
      </el-form-item>
      <el-form-item label="电影上映日期:">
        <el-date-picker
          v-model="filmInfo.data.releaseTime"
          type="date"
          placeholder="选择时间"
          value-format="YYYY-MM-DD"
        />
      </el-form-item>
      <el-form-item class="btnGroup">
        <el-button type="primary" @click="onSubmit">提交修改</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>
#updataView {
  width: 96%;
  /* margin-top: 400px; */
}
#updataView :deep(.el-form-icon) {
  position: relative;
}
.title {
  margin-bottom: 10px;
}
.el-form {
  /* height: 90%; */
  padding: 80px;
}

.btnGroup {
  margin-top: 30px;
}
.el-image >>> .el-icon {
  position: relative;
}
.tag {
  margin-top: 20px;
  display: flex;
  flex-direction: column;
}
.tag >>> .el-icon {
  position: relative;
}
.tag >>> .el-form-item__content {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.tagSelect {
  display: flex;
  flex-direction: row;
  margin-bottom: 10px;
}
.tagSelect .title {
  margin: 0 20px 0 0px;
}
.upload {
  width: 250px;
}
.upload input {
  display: none;
}
.upload .btn {
  width: 60px;
  height: 30px;
  border-radius: 6px;
  background-color: rgb(38, 175, 255);
  text-align: center;
  color: white;
  cursor: pointer;
  margin-left: 20px;
  font-size: 13px;
}
.video {
  width: 300px;
  height: 200px;
  overflow: hidden;
}
.video video {
  width: 100%;
  height: 100%;
}
.performer .scrollbar-flex-content {
  display: flex;
  flex-direction: column;
}
</style>
