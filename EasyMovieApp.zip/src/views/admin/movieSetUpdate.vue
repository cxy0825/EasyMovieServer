<script setup>
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, toRefs, isReactive } from "vue";
import movie from "@/api/movie/movieApi.js";
import movieSet from "@/api/movie/movieSet.js";
import { ElMessage, ElLoading } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
const router = useRouter();
const route = useRoute();
const id = route.params.id;
const mainStore = useMainStore();

//电影院ID

let movieSetInfo = reactive({
  data: {
    id: null,
    movieHouseId: null,
    movieHouseName: null,
    filmId: null,
    filmName: null,
    cinemaId: mainStore.cinemaId,
    movieStartTime: null,
    movieEndTime: null,
  },
});
let title = ref("添加电影排片");

//时间组件
const time = ref([]);
//抽离获取数据方法
const defaultMovieList = ref([]);
//获取放映厅列表
const getMovieHouseData = function (page = 1, size = 10, name = null) {
  movie.getMoveHouseList(page, size, name).then((res) => {
    defaultMovieList.value = res.records;
  });
};

//获取影片列表
let defaultFilm = ref([]);
//抽离获取数据方法
const getFilmData = function (name = "-1", page = 1, size = 10) {
  movie.getFilmINfoList(mainStore.cinemaId, name, page, size).then((res) => {
    defaultFilm.value = res.records;
  });
};

//如果没有接收到ID说明是添加,那么就不需要获取数据
if (id != undefined || id != null) {
  //放映厅ID
  movieSetInfo.data.id = id;
  //   拿到id后获取根据这个id获取详情;
  movieSet.getMovieSetInfoByID(id).then((res) => {
    movieSetInfo.data.movieHouseId = res.movieHouseId;
    movieSetInfo.data.movieHouseName = res.movieHouseName;
    movieSetInfo.data.filmId = res.filmId;
    movieSetInfo.data.filmName = res.filmName;
    movieSetInfo.data.movieStartTime = res.movieEndTime;
    movieSetInfo.data.movieEndTime = res.movieEndTime;
    movieSetInfo.data.price = res.price;
    //显示时间
    time.value[0] = res.movieStartTime;
    time.value[1] = res.movieEndTime;
    title.value = "修改电影排片信息";
  });
  //获取默认的放映厅列表
  getMovieHouseData(1, 10);
  //获取默认的影片列表
  getFilmData("-1", 1, 10);
}

//远程获取标签事件获取电影放映厅列表
function movieHouseRemote(query) {
  if (query) {
    getMovieHouseData(1, 10, query);
  } else {
    getMovieHouseData(1, 10);
  }
}
function filmRemote(query) {
  if (query) {
    getFilmData(query, 1, 10);
  } else {
    getFilmData("-1", 1, 10);
  }
}
//电影放映厅 下拉框
function movieHouseChange(query) {
  for (let item of defaultMovieList.value) {
    if (item.movieHouseName == query) {
      movieSetInfo.data.movieHouseId = item.id;
      break;
    }
  }
}
//电影 下拉框
function filmChange(query) {
  for (let item of defaultFilm.value) {
    if (item.filmName == query) {
      movieSetInfo.data.filmId = item.id;
      break;
    }
  }
}
//更改了时间
function tiemChange(value) {
  movieSetInfo.data.movieStartTime = value[0];
  movieSetInfo.data.movieEndTime = value[1];
}
//提交
const onSubmit = function () {
  const loadingInstance = ElLoading.service({ target: "#updataView" });
  //添加操作
  if (id == undefined || id == null) {
    movieSet
      .addMovieSetInfo(movieSetInfo.data)
      .then((res) => {
        ElMessage({
          showClose: true,
          message: "操作成功",
          type: "success",
        });
        router.push("/admin/main/movieSet/info");
      })
      .finally(() => {
        loadingInstance.close();
      });
  } else {
    //更新操作
    movieSet
      .updateMovieSetInfo(movieSetInfo.data)
      .then((res) => {
        ElMessage({
          showClose: true,
          message: "操作成功",
          type: "success",
        });
        router.push("/admin/main/movieSet/info");
      })
      .finally(() => {
        loadingInstance.close();
      });
  }
};
//取消
const cancel = function () {
  router.push("/admin/main/movieSet/info");
};
</script>
<template>
  <div id="updataView" style="position: relative">
    <div class="title" style="position: absolute; top: 40px; left: 80px">
      {{ title }}
    </div>
    <el-form ref="ruleFormRef" label-position="top" label-width="100px">
      <el-form-item label="选择放映厅" style="width: 300px">
        <el-select
          v-model="movieSetInfo.data.movieHouseName"
          filterable
          remote
          reserve-keyword
          placeholder="选择放映厅"
          :remote-method="movieHouseRemote"
          @change="movieHouseChange"
        >
          <el-option
            v-for="item in defaultMovieList"
            :key="item.id"
            :value="item.movieHouseName"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="选择电影:" style="width: 300px">
        <el-select
          v-model="movieSetInfo.data.filmName"
          filterable
          remote
          reserve-keyword
          placeholder="选择电影"
          :remote-method="filmRemote"
          @change="filmChange"
        >
          <el-option
            v-for="item in defaultFilm"
            :key="item.id"
            :value="item.filmName"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="电影开始-结束时间:" style="width: 500px">
        <el-date-picker
          v-model="time"
          type="datetimerange"
          range-separator="-"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          value-format="YYYY-MM-DD HH:mm:ss"
          @change="tiemChange"
        />
      </el-form-item>
      <el-form-item label="电影票价格(元):">
        <el-input
          v-model="movieSetInfo.data.price"
          placeholder="电影票价格"
          style="width: 190px"
        />
      </el-form-item>

      <el-form-item class="btnGroup">
        <el-button type="primary" @click="onSubmit">提交修改</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>
#updataView {
  width: 96%;
}
.title {
  margin-bottom: 10px;
}
.el-form {
  /* height: 90%; */
  padding: 80px;
}

.btnGroup {
  margin-top: 30px;
  display: flex;
  justify-content: center;
}
.btnGroup >>> .el-form-item__content {
  justify-content: center;
}
</style>
