<script setup>
import { ref, reactive, toRef } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ElMessage, ElLoading } from "element-plus";
import tag from "@/api/tag/tag.js";
const router = useRouter();
const route = useRoute();
const tagName = route.params.tagName;

const title = ref("添加标签");
const tagObj = reactive({
  data: {},
});
if (tagName != undefined || tagName != null) {
  title.value = "修改标签";
  tag.getTagInfoByName(tagName).then((res) => {
    tagObj.data = res[0];
  });
}

//提交
const onSubmit = function () {
  const loadingInstance = ElLoading.service({ target: "#updataView" });
  tag
    .updateTag(tagObj.data)
    .then((res) => {
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      });

      router.push("/admin/main/tag/search");
    })
    .finally(() => {
      loadingInstance.close();
    });
};
//取消
const cancel = function () {
  router.push("/admin/main/tag/search");
};
//根据名称去查询标签信息
</script>
<template>
  <div id="updataView" style="position: relative">
    <div class="title" style="position: absolute; top: 40px; left: 80px">
      {{ title }}
    </div>
    <el-form
      ref="ruleFormRef"
      label-position="top"
      label-width="100px"
      :model="tagObj.data"
    >
      <el-form-item label="标签ID:" v-if="tagObj.data.id != null">
        <el-input
          v-model="tagObj.data.id"
          :disabled="true"
          style="width: 120px"
        />
      </el-form-item>
      <el-form-item label="标签名字:">
        <el-input v-model="tagObj.data.tagName" style="width: 300px" />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="onSubmit">提交修改</el-button>
        <el-button @click="cancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<style scoped>
.el-form {
  width: 90%;
  height: 90%;
  padding: 80px 150px;
}
.el-form-item {
  margin-bottom: 35px;
}
.group {
  display: flex;
  justify-content: space-between;
}
</style>
