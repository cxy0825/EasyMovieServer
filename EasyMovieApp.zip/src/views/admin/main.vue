<script setup>
import { ref, reactive, watch } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ElMessage } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
import { storeToRefs } from "pinia";
import mmenu from "@/views/admin/menu.vue";
const mainStore = useMainStore();
let { name, account } = storeToRefs(mainStore);
const router = useRouter();
const route = useRoute();
// console.log(route.meta);
//面包屑导航
// let breadcrumbList = reactive([]);

//当前路由列表
// console.log(router);
// 登出
const loginOut = function () {
  localStorage.removeItem("token");
  localStorage.removeItem("refreshToken");
  //重置pinia
  mainStore.$reset();
  router.push("/admin/login");
  //提示
  ElMessage({
    showClose: true,
    message: "注销成功",
    type: "success",
  });
};
</script>
<template>
  <div class="container">
    <el-row class="header">
      <el-col :span="4">
        <div class="logo">
          <img src="@/assets/static/img/logo.png" />
        </div>
      </el-col>
      <el-col :span="20" class="title">
        <el-row align="middle">
          <el-col :span="10" style="color: white">EM电影后台管理</el-col>
          <el-col :span="3" :offset="11">
            <el-link type="primary" style="color: white" @click="loginOut"
              >注销</el-link
            >
          </el-col>
        </el-row>
      </el-col>
    </el-row>

    <el-row class="body">
      <el-col :span="4" class="select">
        <mmenu></mmenu>
      </el-col>
      <el-col :span="20" class="view">
        <router-view
          v-slot="{ Component, route }"
          style="background-color: white"
        >
          <transition name="fade" mode="out-in">
            <component :is="Component" :key="route.path" />
          </transition>
        </router-view>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.container {
  width: 100vw;
  height: 100vh;
  max-height: 100vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.header {
  height: 60px;
  background: #3f82ff;
}
.header .el-row {
  height: 100%;
}
.header .title {
  padding: 0 15px;
}
.logo {
  width: 100%;
  height: 60px;
  background-color: #3f7cf0;
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.logo img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
  margin-left: 10px;
}
.banner {
  width: 100%;
  height: 80px;
  min-height: 80px;
  box-shadow: 0px 14px 20px 1px #d7d7d7;
}

.body {
  width: 100%;
  flex: 1 1 auto;
  flex-direction: row;
  overflow: hidden;
}
.body .select {
  display: flex;
  align-items: center;
  flex-direction: column;
  overflow: hidden;
  height: 100%;
}
.body .select .tree {
  width: 100%;
}
.view {
  padding: 10px 10px;
  background: #fafafa;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  overflow: hidden;
  overflow-y: scroll;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
.fade-enter-to,
.fade-leave {
  opacity: 1;
}
.fade-enter-active,
.fade-leave-active {
  transition: all 0.5s ease-in-out;
}
</style>
