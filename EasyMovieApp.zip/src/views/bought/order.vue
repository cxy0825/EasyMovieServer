<script setup>
import pageHead from "@/components/pageHead.vue";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, onMounted, onActivated, computed } from "vue";
import orderInfo from "@/api/order/orderInfo.js";
import buy from "@/api/order/buy.js";
const route = useRoute();
const router = useRouter();
const paymentID = route.params.orderID;
const paymentInfo = reactive({
  data: {
    id: "111",
    userId: "10001",
    userType: "0",
    productId: "17",
    productType: "ticket",
    productNum: 1,
    productInfo: "[[3,4,1],[3,5,1],[3,6,1]]",
    paymentAmount: 3.0,
    voucherId: "1605183943376285697",
    preferentialAmount: 1.0,
    finalPaymentAmount: 2.0,
    createtime: "2023-01-13 14:55:46",
    updatatime: "2023-01-13 14:55:46",
  },
});

//获得订单数据
//订单剩余时间
const time = ref(0);
orderInfo.getOrderInfo(paymentID).then((res) => {
  paymentInfo.data = res;
});

//去支付
function pay() {
  buy.createZFBorder(paymentID).then((res) => {
    router.go(-1);
    let myWindow = window.open("", "width=200,height=100");
    myWindow.document.write(res);
    myWindow.focus();
  });
}
</script>
<template>
  <div class="root">
    <div class="head">
      <pageHead />
    </div>
    <div class="order">
      <div class="result">
        <el-result
          icon="success"
          title="创建订单成功"
          sub-title="请在30分钟内支付"
        ></el-result>
      </div>
      <div><span>订单号: </span>{{ paymentInfo.data.id }}</div>
      <div v-if="paymentInfo.data.productType == 'ticket'" class="seatInfo">
        <span>座位号: </span>
        <div class="info">
          <span v-for="(item, i) in JSON.parse(paymentInfo.data.productInfo)">
            {{ item[0] + 1 }}排{{ item[1] + 1 }}列</span
          >
        </div>
      </div>
      <div><span>总金额: </span>{{ paymentInfo.data.paymentAmount }}</div>
      <div>
        <span>优惠金额: </span>{{ paymentInfo.data.preferentialAmount }}
      </div>
      <div>
        <span>最终支付: </span>{{ paymentInfo.data.finalPaymentAmount }}
      </div>
      <div><span>创建时间: </span>{{ paymentInfo.data.createtime }}</div>
    </div>
    <div class="btn">
      <el-button type="danger" @click="pay">去支付</el-button>
    </div>
  </div>
</template>

<style scoped>
.head {
  width: 100%;
  height: 80px;
  background-color: #444444;
}
.order {
  padding: 0 15px;
  font-size: 15px;
}
.order > div {
  margin-bottom: 10px;
}
.seatInfo {
  width: 100%;
  display: flex;
  flex-direction: row;
}
.seatInfo > span {
  min-width: 55px;
}
.seatInfo .info span {
  margin-right: 5px;
  color: crimson;
}
.btn {
  width: 100%;
  text-align: center;
  margin-top: 20px;
}
.btn :deep(button) {
  width: 300px;
}
</style>
