<script setup>
import pageHead from "@/components/pageHead.vue";
import seatInfo from "@/components/seatInfo.vue";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, onMounted, onActivated, computed } from "vue";
import movie from "@/api/movie/movieApi.js";
import movieSet from "@/api/movie/movieSet.js";
import buy from "@/api/order/buy.js";
import voucher from "@/api/voucher/voucherApi.js";

const route = useRoute();
const router = useRouter();
const movieSetID = route.params.movieSetID;
const info = reactive({
  data: {
    id: 1,
    filmName: "",
    about: "",
    releaseTime: "",
    duration: null,
    score: null,
    videoUrls: [],
    posterUrls: [],
    tags: [],
  },
});
const movieSetInfo = reactive({
  data: {},
});
//根据排片ID获取排片信息
movieSet.getMovieSetInfoByID(movieSetID).then((movieSetRes) => {
  movieSetInfo.data = movieSetRes;
  //获得相关数据
  movie.getFilmINfoById(movieSetRes.filmId).then((filmRes) => {
    info.data = filmRes;
  });
});

//子组件传递的数据
//购买的位置
const buyArr = ref([]);
console.log(buyArr.value.length);

function change(sub) {
  buyArr.value = sub;
}
//优惠券模块
let voucherID = ref(null);
let voucherInfo = reactive({
  data: [],
});
//获取持有的优惠券
voucher.getVoucherByUser().then((res) => {
  voucherInfo.data = res;
});
function a() {
  console.log(voucherID.value);
}
//不使用优惠券
function noUse() {
  voucherID.value = null;
}
//点击购买按钮
function buyTickets() {
  if (buyArr.value.length == 0) {
    return false;
  }
  //添加已购买标识位1
  buyArr.value.forEach((item) => {
    item.push(1);
  });
  buy.buyTickets(movieSetID, buyArr.value, voucherID.value).then((res) => {
    router.push(`/bought/order/${res}`);
    // console.log(res);
  });
}
</script>
<template>
  <div class="root">
    <pageHead />
    <div class="container">
      <div class="header">
        <div
          class="bg"
          :style="{ backgroundImage: 'url(' + info.data.posterUrls[0] + ')' }"
        ></div>
        <div class="f"></div>
        <div class="content">
          <div class="img">
            <img :src="info.data.posterUrls[0]" />
          </div>
          <div class="text">
            <div class="title">
              <el-tooltip
                class="box-item"
                effect="dark"
                :content="info.data.filmName"
                placement="top"
              >
                {{ info.data.filmName }}
              </el-tooltip>
            </div>
            <div class="rate">
              <el-rate
                :model-value="info.data.score / 2"
                disabled
                show-score
                disabled-void-color="rgb(238, 238, 238)"
                score-template="{value} 分"
              />
            </div>
            <div class="tip">
              <p v-for="(item, i) in info.data.tags" :key="i">
                {{ item }}
              </p>
            </div>
            <div class="duration">
              <p>时长: {{ info.data.duration }}分钟</p>
            </div>
            <div class="time">
              <p>开始时间:{{ movieSetInfo.data.movieStartTime }}</p>
              <p>结束时间:{{ movieSetInfo.data.movieEndTime }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="body">
        <div class="seatInfo">
          <seatInfo
            @change="change"
            :movieHouseID="movieSetInfo.data.movieHouseId"
            :movieSetID="movieSetID"
          />
        </div>
        <div class="buy">
          <div class="title">
            <p>选择座位</p>
          </div>
          <div class="select">
            <p v-for="(item, i) in buyArr" :key="i">
              {{ item[0] + 1 }}排{{ item[1] + 1 }}座
            </p>
          </div>
          <div class="total" v-if="buyArr.length > 0">
            <span>共:</span> ￥{{ buyArr.length * movieSetInfo.data.price }}
          </div>
        </div>
        <div class="voucher">
          <div class="title" @click="noUse">不使用优惠券</div>
          <el-radio-group v-model="voucherID" @change="a">
            <el-radio
              :label="item.id"
              v-for="(item, i) in voucherInfo.data"
              :key="i"
              >{{ item.title }}</el-radio
            >
          </el-radio-group>
        </div>
        <div class="button">
          <el-button
            type="danger"
            round
            @click="buyTickets"
            :disabled="buyArr.length <= 0"
            >购买</el-button
          >
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import "@/assets/static/css/movie.css";
.root {
  display: flex;
  flex-direction: column;
}
.header .content .time {
  font-size: 14px;
  color: #dfdfdf;
  margin-top: 5px;
}

.body {
  background-color: #fff;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}
.voucher {
  padding: 0 15px;
  display: flex;
  flex-direction: column;
}
.voucher .title {
  font-size: 12px;
  color: rgb(219, 85, 85);
  border: 1px solid rgb(219, 85, 85);
  border-radius: 8px;
  width: 90px;
  padding: 5px;
  text-align: center;
  float: right;
}

.voucher .el-radio-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.voucher .el-radio-group::deep(.el-radio) {
  margin: 0;
}
.buy {
  width: 100%;
  display: flex;
  flex-direction: column;
  padding: 0 15px;
}
.buy .title {
  color: #cccccc;
  font-size: 15px;
  margin-bottom: 8px;
}
.buy .select {
  color: rgb(238, 52, 86);
  font-size: 16px;
  font-weight: 600;
  display: flex;
  flex-wrap: wrap;
}
.buy .select p {
  margin-right: 10px;
}
.buy .total {
  color: rgb(238, 52, 86);
  text-align: right;
}
.buy .total span {
  font-size: 14px;
}
.button {
  width: 100%;
  padding: 5px 15px;
  margin-top: 10px;
  padding-bottom: 10px;
}
.button :deep(button) {
  width: 100%;
}
</style>
