<script setup>
import mongo from "@/api/mongo/mongoApi.js";
import { ref, reactive, watch } from "vue";
import { ElMessage, ElLoading, ElMessageBox } from "element-plus";

const tableData = ref([]);
const shouchang = ref([]);
//获得列表
mongo.getShouchang().then((res) => {
  tableData.value = res;
});

function sc(ID) {
  mongo.csc(ID).then((res) => {
    mongo.getShouchang().then((res) => {
      tableData.value = res;
    });
  });
}
</script>
<template>
  <div class="movieContainer">
    <div class="table">
      <el-table
        ref="multipleTableRef"
        :data="tableData"
        stripe
        show-header
        highlight-current-row
        height="100%"
        style="width: 100%"
      >
        <el-table-column prop="_id" label="ID" width="60" />
        <el-table-column prop="name" label="基金名字" show-overflow-tooltip />
        <el-table-column prop="type" label="基金类型" />
        <el-table-column
          prop="birthday"
          label="上市日期"
          show-overflow-tooltip
        />
        <el-table-column prop="price" label="当前价格" />

        <el-table-column label="操作" width="300">
          <template #default="scope">
            <el-button type="danger" plain @click="sc(scope.row._id)"
              >取消收藏</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<style>
.movieContainer {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
}
.h {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.search {
  width: 300px;
  display: flex;
  justify-self: center;
  align-items: center;
}
.search .el-input {
  width: 200px;
  margin: 5px 10px;
}
.table {
  width: 100%;
  height: 450px;
  display: flex;
  overflow-y: scroll;
  flex: 1 1 auto;
}
.table .el-table__row--striped {
  background: #f3f3f3;
}
.table .cell {
  color: #000;
  text-align: center;
}
.page {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 10px;
  height: 50px;
}
.page .el-icon {
  position: relative;
}
</style>
