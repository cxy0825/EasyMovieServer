<script setup>
import mongo from "@/api/mongo/mongoApi.js";
import { ref, reactive, watch } from "vue";
import { ElMessage, ElLoading, ElMessageBox } from "element-plus";
import { useRouter, useRoute, onBeforeRouteLeave } from "vue-router";
const tableData = ref([]);
const shouchang = ref([]);
const route = useRoute();
console.log(route);

onBeforeRouteLeave((to, from) => {
  from.meta = {};
});
const ID = route.meta.ID;
//抽离获取列表的方法
function getData() {
  if (ID != null || ID != undefined) {
    mongo.getjjById(ID.value).then((res) => {
      tableData.value = res.jijings;
    });
  } else {
    //获得列表
    mongo.getAlljijing().then((res) => {
      tableData.value = res;
    });
  }
}
getData();
//获得自己的收藏
mongo.getShouchang().then((res) => {
  shouchang.value.length = 0;
  for (let item of res) {
    shouchang.value.push(item._id);
  }
});

function buy(ID, price) {
  ElMessageBox.prompt("你要买多少份额的基金?", "Tip", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    inputPattern: /^\d*$/,
  }).then(({ value }) => {
    mongo.buy(ID, value, price).then(
      ElMessage({
        showClose: true,
        message: "操作成功",
        type: "success",
      })
    );
  });
}

function sc(ID) {
  mongo.sc(ID).then((res) => {
    //重新获取一次
    getData();
    shouchang.value.push(ID);
  });
}
//分页
//当前是第几页
let currentPage = ref(1);
//页数改变就重新获取
watch(currentPage, (newValue, oldValue) => {
  mongo.getAlljijing(currentPage.value).then((res) => {
    tableData.value = res;
  });
});
</script>
<template>
  <div class="movieContainer">
    <div class="table">
      <el-table
        ref="multipleTableRef"
        :data="tableData"
        stripe
        show-header
        highlight-current-row
        height="100%"
        style="width: 100%"
      >
        <el-table-column prop="_id" label="ID" width="60" />
        <el-table-column
          prop="name"
          label="基金名字"
          show-overflow-tooltip
          sortable
        />
        <el-table-column prop="type" label="基金类型" sortable />
        <el-table-column
          prop="birthday"
          label="上市日期"
          show-overflow-tooltip
          sortable
        />
        <el-table-column prop="price" label="当前价格" sortable />

        <el-table-column label="操作" width="300">
          <template #default="scope">
            <el-button
              type="primary"
              plain
              @click="buy(scope.row._id, scope.row.price)"
              >购买</el-button
            >
            <el-button
              type="danger"
              plain
              @click="sc(scope.row._id)"
              :disabled="shouchang.includes(scope.row._id)"
              >收藏</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="page">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="2 * 10"
        next-text="下一页"
        prev-text="上一页"
        v-model:currentPage="currentPage"
      />
    </div>
  </div>
</template>

<style>
.movieContainer {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
}
.h {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.search {
  width: 300px;
  display: flex;
  justify-self: center;
  align-items: center;
}
.search .el-input {
  width: 200px;
  margin: 5px 10px;
}
.table {
  width: 100%;
  height: 450px;
  display: flex;
  overflow-y: scroll;
  flex: 1 1 auto;
}
.table .el-table__row--striped {
  background: #f3f3f3;
}
.table .cell {
  color: #000;
  text-align: center;
}
.page {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 10px;
  height: 50px;
}
.page .el-icon {
  position: relative;
}
</style>
