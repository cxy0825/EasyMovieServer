<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { useMainStore } from "@/pinia/mainStore.js";
const mainStore = useMainStore();
const router = useRouter();
</script>
<template>
  <div class="my-collapse">
    <div class="userInfo">
      <div class="name">你好: {{ mainStore.name }}</div>
    </div>
    <el-menu
      :default-active="router.currentRoute.value.path"
      router
      class="el-menu-vertical-demo"
    >
      <el-sub-menu index="/mongo/1">
        <template #title>
          <span>公司</span>
        </template>
        <el-menu-item index="/mongo/gongsi" router="/mongo/gongsi">
          <template #title>查看公司信息</template>
        </el-menu-item>
        <el-menu-item index="/mongo/jijing" router="/mongo/jijing">
          <template #title>查看基金列表</template>
        </el-menu-item>
      </el-sub-menu>
      <el-sub-menu index="/mongo/2">
        <template #title>
          <span>个人基金管理</span>
        </template>
        <el-menu-item index="/mongo/person" router="/mongo/person">
          <template #title>我的基金</template>
        </el-menu-item>
        <el-menu-item index="/mongo/sc" router="/mongo/sc">
          <template #title>我的收藏</template>
        </el-menu-item>
      </el-sub-menu>
    </el-menu>
  </div>
</template>

<style>
.userInfo {
  width: 100%;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: darkgrey;
  font-size: 14px;
}
.my-collapse {
  width: 100%;
}
.my-collapse .el-collapse-item__header {
  width: 100%;
  text-align: center;
  font-size: 14px;
  display: flex;
  justify-content: center;
  position: relative;
}
.el-icon {
  position: absolute;
  right: 0;
}
.my-collapse .item {
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  color: #a1a1a1;
}
.my-collapse .item.active {
  background: #3f82ff;
  color: #fff;
}
.my-collapse .item:hover {
  background: #3f82ff;
  color: #fff;
}
.my-collapse .item span {
  text-decoration: none;

  font-size: 14px;
}
</style>
