<script setup>
import pageHeadVue from "@/components/pageHead.vue";
import comment from "@/views/movie/comment.vue";
import { ref, reactive } from "vue";
import { storeToRefs } from "pinia";
import { ElMessage } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
import { useRouter, useRoute } from "vue-router";
import movie from "@/api/movie/movieApi.js";
const route = useRoute();
const router = useRouter();
const id = route.params.id;
const info = reactive({
  data: {
    id: 1,
    filmName: "",
    about: "",
    releaseTime: "",
    duration: null,
    score: null,
    videoUrls: [],
    posterUrls: [],
    tags: [],
  },
});
const performerList = ref([]);
//tab标签优先显示那一项
const activeName = ref("first");
//稍后获取数据完成关闭骨架屏
const isLoading = ref(true);
//获得相关数据
movie.getFilmINfoById(id).then((res) => {
  info.data = res;
  isLoading.value = false;
});
//获取演员信息
movie.getPerformerByFilmID(id).then((res) => {
  performerList.value = res;
});
//根据电影ID跳转到电影界面
function toFilmView(filmName) {
  router.push("/main/cinema/" + filmName);
}
//根据演员ID跳转到演员详情界面
function toPerformerView(performerID) {
  router.push("/movie/performer/" + performerID);
}
</script>
<template>
  <div class="root">
    <pageHeadVue />
    <div class="el-skeleton" v-if="isLoading">
      <el-skeleton style="width: 90vw" animated>
        <template #template>
          <el-skeleton-item
            variant="image"
            style="width: 100vw; height: 240px"
          />
          <div style="padding: 15px">
            <el-skeleton-item variant="p" style="width: 50%" />
            <el-skeleton-item variant="text" style="margin-right: 16px" />
            <el-skeleton-item variant="text" style="width: 90%" />
            <el-skeleton-item variant="text" style="width: 80%" />
            <el-skeleton-item variant="text" style="width: 80%" />
            <el-skeleton-item variant="text" style="width: 60%" />
            <el-skeleton-item variant="text" style="width: 50%" />
            <el-skeleton-item variant="text" style="width: 80%" />
          </div>
        </template>
      </el-skeleton>
    </div>
    <div class="container" v-else>
      <div class="header">
        <div
          class="bg"
          :style="{ backgroundImage: 'url(' + info.data.posterUrls[0] + ')' }"
        ></div>
        <div class="f"></div>
        <div class="content">
          <div class="img">
            <img :src="info.data.posterUrls[0]" />
          </div>
          <div class="text">
            <div class="title">
              <el-tooltip
                class="box-item"
                effect="dark"
                :content="info.data.filmName"
                placement="top"
              >
                {{ info.data.filmName }}
              </el-tooltip>
            </div>
            <div class="rate">
              <el-rate
                :model-value="info.data.score / 2"
                disabled
                show-score
                disabled-void-color="rgb(238, 238, 238)"
                score-template="{value} 分"
              />
            </div>
            <div class="tip">
              <p v-for="(item, i) in info.data.tags" :key="i">
                {{ item }}
              </p>
            </div>
            <div class="duration">
              <p>时长: {{ info.data.duration }}分钟</p>
            </div>
            <div class="releaseTime">
              <p>上映时间: {{ info.data.releaseTime }}</p>
            </div>
            <div class="button">
              <el-button type="info" @click="toFilmView(info.data.filmName)"
                >我想看</el-button
              >
            </div>
          </div>
        </div>
      </div>
      <div class="about">
        <div class="h">
          <p>简介</p>
        </div>
        <div class="content">
          {{ info.data.about }}
        </div>
      </div>
      <div class="performer">
        <div class="h">
          <p>演职人员</p>
        </div>
        <el-scrollbar>
          <div class="scrollbar-flex-content">
            <div
              class="scrollbar-flex-item"
              v-for="(item, i) in performerList"
              :key="i"
              @click="toPerformerView(item.id)"
            >
              <img :src="item.performerPicUrl" style="height: 140px" />
              <p>{{ item.performerName }}</p>
            </div>
          </div>
        </el-scrollbar>
      </div>
      <div class="view">
        <el-tabs v-model="activeName" class="demo-tabs">
          <el-tab-pane label="视频" name="first">
            <el-scrollbar>
              <div class="scrollbar-flex-content">
                <div
                  class="scrollbar-flex-item"
                  v-for="(item, i) in info.data.videoUrls"
                  :key="i"
                >
                  <video width="240" controls>
                    <source :src="item" type="video/mp4" />
                  </video>
                </div>
              </div>
            </el-scrollbar>
          </el-tab-pane>
          <el-tab-pane label="剧照" name="second">
            <el-scrollbar>
              <div class="scrollbar-flex-content">
                <div
                  class="scrollbar-flex-item"
                  v-for="(item, i) in info.data.posterUrls"
                  :key="i"
                >
                  <el-image
                    style="width: 120px"
                    :src="item"
                    :zoom-rate="1.2"
                    :initial-index="0"
                    :preview-src-list="info.data.posterUrls"
                    fit="cover"
                  />
                  <img src="" />
                </div>
              </div>
            </el-scrollbar>
          </el-tab-pane>
        </el-tabs>
      </div>
      <comment :filmID="id" />
    </div>
  </div>
</template>

<style scoped>
@import "@/assets/static/css/movie.css";
</style>
