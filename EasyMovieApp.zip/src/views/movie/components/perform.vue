<script setup>
import { ref, reactive } from "vue";
import { useRouter, useRoute } from "vue-router";
import performer from "@/api/movie/performerApi.js";
const router = useRouter();
const route = useRoute();
const performInfo = reactive({
  data: [],
});
//获取数据
performer.getPerformInfo(route.params.id).then((res) => {
  // console.log(res);
  performInfo.data = res;
});
//点击图片跳转到对应的电影页面
function toFilmView(filmID) {
  router.push(`/movie/${filmID}`);
}
</script>
<template>
  <div class="perform">
    <div class="title">与他有关</div>
    <ul class="list">
      <li v-for="(item, i) in performInfo.data" :key="i">
        <div class="container">
          <div class="img" @click="toFilmView(item.id)">
            <img :src="item.posterUrls[0]" alt="" />
          </div>
          <div class="text">
            <div class="title" :title="item.filmName">{{ item.filmName }}</div>
            <div class="rate">
              <el-rate
                :model-value="item.score / 2"
                disabled
                show-score
                disabled-void-color="rgb(238, 238, 238)"
                score-template="{value} 分"
                size="small"
              />
            </div>
            <div class="tip">
              <p v-for="(tip, i) in item.tags" :key="i">
                {{ tip }}
              </p>
            </div>
          </div>
        </div>
      </li>
    </ul>
  </div>
</template>

<style scoped>
.perform .title {
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 0.8px;
  margin-bottom: 20px;
}

ul > li {
  list-style: none;
  width: 100%;
  max-height: 135px;
  border-bottom: 1px solid rgb(223, 223, 223);
  padding-bottom: 8px;
}
ul > li .container {
  width: 100%;
  padding: 10px 0;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
}
ul > li .container .img {
  max-width: 80px;
}
ul > li .container .img img {
  width: 100%;
  border-radius: 6px;
  object-fit: cover;
}
ul > li .container .text {
  width: 260px;
}
ul > li .container .text .title {
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-bottom: 10px;
  font-size: 14px;
  color: rgb(56, 56, 56);
}
ul > li .container .text .tip {
  width: 100%;
  display: flex;
  color: rgb(160, 160, 160);
  font-size: 12px;
}
ul > li .container .text .tip p {
  margin-right: 3px;
  border: 1px solid rgb(160, 160, 160);
  border-radius: 3px;
  padding: 1px 3px;
  transform: scale(0.9);
}
</style>
