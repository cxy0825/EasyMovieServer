<script setup>
import movie from "@/api/movie/movieApi.js";
import { ref, reactive, defineProps } from "vue";
const props = defineProps({
  filmID: {
    type: String,
  },
});
const commitInfo = reactive({
  data: {
    _id: null,
    commits: [
      {
        id: null,
        userID: "1",
        name: "root",
        avatarUrl: null,
        content: "测试内容",
        time: "2023-01-20 15:46",
      },
    ],
  },
});
movie.getCommit(props.filmID).then((res) => {
  commitInfo.data = res;
});
const commit = ref("");
function send() {
  if (commit.value.trim() == "") {
    return false;
  }
  movie.sendCommit(props.filmID, commit.value).then((res) => {
    //清空输入栏
    commit.value = "";
    //重新获取数据
    movie.getCommit(props.filmID).then((res) => {
      commitInfo.data = res;
    });
  });
}
</script>
<template>
  <div class="commit">
    <div class="title">评论区</div>

    <div class="list" v-if="commitInfo.data != null">
      <div class="item" v-for="(item, i) in commitInfo.data.commits" :key="i">
        <div class="head">
          <div class="avatar">
            <img :src="item.avatarUrl" />
          </div>
          <div class="info">
            <div class="name">{{ item.name }}</div>
            <div class="time">{{ item.time }}</div>
          </div>
        </div>
        <div class="body">{{ item.content }}</div>
      </div>
    </div>
    <div class="inputContrain">
      <div class="input">
        <el-input placeholder="评论内容" v-model="commit" />
        <el-button type="primary" @click="send">发送</el-button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.commit {
  color: white;
  position: relative;
}
.commit .title {
  padding: 0 15px;
  font-weight: 600;
  margin-bottom: 15px;
}
.commit .list {
  padding: 20px 15px 10px;
  width: 100%;
  background-color: white;
  border-top-left-radius: 16px;
  border-top-right-radius: 16px;
  padding-bottom: 50px;
}
.commit .list .item {
  padding-bottom: 10px;
  margin-bottom: 8px;
  border-bottom: 1px solid rgb(231, 231, 231);
}
.commit .list .head {
  display: flex;
  margin-bottom: 10px;
}

.commit .list .avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  overflow: hidden;
}
.commit .list .avatar img {
  width: 100%;
}
.commit .list .head .info {
  flex: 1;
  display: flex;
  flex-direction: column;
  color: rgb(192, 192, 192);
  justify-content: center;
  margin-left: 5px;
}
.commit .list .head .info .name {
  font-size: 12px;
  margin-bottom: 2px;
}
.commit .list .head .info .time {
  font-size: 12px;
}
.commit .list .body {
  width: 100%;
  color: rgb(0, 0, 0);
  font-size: 14px;
  letter-spacing: 1.5px;
}

.commit .inputContrain {
  width: 100%;
  /* height: 60px; */
  position: fixed;
  bottom: 15px;
}
.commit .inputContrain .input {
  display: flex;
  justify-content: center;
}
.commit .inputContrain .el-input {
  width: 300px;
  margin-right: 10px;
}
</style>
