<script setup>
import pageHeadVue from "@/components/pageHead.vue";
import perform from "@/views/movie/components/perform.vue";
import { ref, reactive } from "vue";
import { storeToRefs } from "pinia";
import { ElMessage } from "element-plus";
import { useMainStore } from "@/pinia/mainStore.js";
import { useRouter, useRoute } from "vue-router";
import movie from "@/api/movie/movieApi.js";
import performer from "@/api/movie/performerApi.js";

const route = useRoute();
const router = useRouter();
const performerID = route.params.id;
const performerInfo = reactive({
  data: {
    id: null,
    performerName: null,
    performerPicUrl: null,
    birthday: null,
    performerAbout: null,
  },
});
const isLoading = ref(true);
performer.getPerformerInfo(performerID).then((res) => {
  performerInfo.data = res;
  isLoading.value = false;
});
//获取演员信息
</script>
<template>
  <div class="root">
    <pageHeadVue />
    <div class="el-skeleton" v-if="isLoading">
      <el-skeleton style="width: 90vw" animated>
        <template #template>
          <el-skeleton-item
            variant="image"
            style="width: 100vw; height: 240px"
          />
          <div style="padding: 15px">
            <el-skeleton-item variant="p" style="width: 50%" />
            <el-skeleton-item variant="text" style="width: 90%" />
          </div>
        </template>
      </el-skeleton>
    </div>
    <div class="container" v-else>
      <div class="header">
        <div
          class="bg"
          :style="{
            backgroundImage: 'url(' + performerInfo.data.performerPicUrl + ')',
          }"
        ></div>
        <div class="content">
          <div class="text">
            <div class="name">
              <p>{{ performerInfo.data.performerName }}</p>
            </div>
            <div class="birthday">
              <p>{{ performerInfo.data.birthday }}</p>
            </div>
          </div>
          <div class="img">
            <img :src="performerInfo.data.performerPicUrl" alt="" />
          </div>
        </div>
      </div>
      <div class="b">
        <div class="about">
          <div class="title">影人简介</div>
          <div class="d">
            {{ performerInfo.data.performerAbout }}
          </div>
        </div>
        <perform />
      </div>
    </div>
  </div>
</template>

<style scoped>
.root {
  width: 100vw;
  min-height: 100vh;
  background-color: white;
}
.root .container {
  position: relative;
}
.root .container .header {
  width: 100%;
  height: 280px;
  position: relative;
  z-index: 1;
}
.root .container .header .bg {
  position: absolute;
  z-index: -1;
  width: 100%;
  height: 100%;
  background-image: url("https://p0.pipi.cn/basicdata/25bfd6d7807338c696b12de58f921755d71eb.png?imageView2/1/w/464/h/644");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
}
.root .container .header .bg::after {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
  width: 100%;
  height: 100%;
  content: "";
  background-image: linear-gradient(
    to bottom,
    rgba(0, 0, 0, 0.4),
    rgba(0, 0, 0, 0.4)
  );
}
.root .container .header .content {
  padding: 0 15px;
  width: 100%;
  height: 100%;
  color: rgb(223, 223, 223);
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  padding-bottom: 50px;
}
.root .container .header .content .text {
  display: flex;
  flex-direction: column;
  max-width: 260px;
  align-self: center;
}
.root .container .header .content .text .name {
  width: 100%;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  font-weight: 600;
}
.root .container .header .content .text .birthday > p {
  font-size: 12px;
  color: rgb(114, 114, 114);
  font-weight: 700;
  margin-top: 10px;
  letter-spacing: 0.3px;
}
.root .container .header .content .img {
  min-width: 80px;
  max-width: 100px;
}
.root .container .header .content .img img {
  width: 100%;
  border-radius: 6px;
  overflow: hidden;
}
.root .container .b {
  position: relative;
  z-index: 1;
  width: 100;
  padding: 30px 15px 0;
  border-radius: 18px;
  transform: translateY(-30px);
  background-color: white;
}
.root .container .b .about {
  margin-bottom: 30px;
}
.root .container .b .about .title {
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 0.6px;
  margin-bottom: 20px;
}
.root .container .b .about .d {
  width: 100%;
  font-size: 14px;
  color: rgb(99, 99, 99);
}
</style>
