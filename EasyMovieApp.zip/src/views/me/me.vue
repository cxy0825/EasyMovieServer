<script setup>
import { ref, reactive, computed } from "vue";
import { useRouter, useRoute } from "vue-router";
import { useMainStore } from "@/pinia/mainStore.js";
import { storeToRefs } from "pinia";
import user from "@/api/users/user.js";
import administrator from "@/api/users/Administrator.js";
const mainStore = useMainStore();

const { name, avatarUrl, power } = storeToRefs(mainStore);
const router = useRouter();
const isVip = computed(() => {
  if (power.value == "0") {
    return "立即开通";
  } else {
    return "已购买";
  }
});

function buy() {
  // power.value = "1";
  user.openingVIP().then((res) => {
    //存入到localstore中
    localStorage.setItem("token", res);
    //重新获取用户信息
    //发送请求获取用户信息
    administrator.getInfo().then((res) => {
      mainStore.userId = res.id;
      mainStore.cinemaId = res.cinemaId;
      mainStore.name = res.name;
      mainStore.account = res.account;
      mainStore.avatarUrl = res.avatarUrl;
      mainStore.power = res.power;
      mainStore.type = res.type;
    });
  });
}

function toBuyView() {
  router.push("/main/filmOrder");
}
function toVoucherView() {
  router.push("/main/voucher");
}
</script>
<template>
  <div class="root">
    <div class="header">
      <div class="ava">
        <img :src="avatarUrl" />
      </div>
      <div class="info">
        <div class="title">{{ name }}</div>
        <div class="v" v-if="power >= 1">
          <img src="@/assets/static/img/vip1.png" alt="" />
        </div>
      </div>
    </div>
    <div class="vip">
      <div class="content">
        <div class="text">
          <div class="title">会员VIP</div>
          <div class="detail">开通VIP会员,享9折购票</div>
        </div>
        <div class="button">
          <el-button
            type="warning"
            round
            :disabled="isVip == '已购买'"
            @click="buy"
            >{{ isVip }}</el-button
          >
        </div>
      </div>
    </div>
    <div class="list">
      <div class="item" @click="toBuyView()">
        <div class="icon">
          <img src="@/assets/static/img/电影票.png" />
        </div>
        <p>我的购票</p>
      </div>
      <div class="item" @click="toVoucherView()">
        <div class="icon">
          <img src="@/assets/static/img/优惠券.png" />
        </div>
        <p>我的优惠券</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.header {
  width: 100%;
  height: 180px;
  background-image: linear-gradient(
    to bottom,
    rgb(255, 244, 250) 10%,
    rgb(251, 249, 247) 90%,
    rgb(255, 255, 255)
  );
  padding-top: 60px;
  display: flex;
  align-items: center;
}
.header .ava {
  width: 60px;
  height: 60px;
  overflow: hidden;
  border-radius: 50%;
  margin-left: 30px;
  margin-right: 10px;
}

.header .ava img {
  width: 100%;
}
.header .info {
  color: #000;
}
.header .info .v {
  width: 60px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.header .info .v img {
  width: 100%;
}
.vip {
  width: 100%;
  height: 100px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.vip .content {
  width: 90%;
  height: 70px;
  background-image: linear-gradient(
    to right,
    rgb(243, 231, 207),
    rgb(231, 197, 137)
  );
  border-radius: 12px;
  font-size: 16px;
  color: rgb(91, 56, 6);
  font-weight: 600;
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.vip .content .text .title {
  font-size: 16px;
}
.vip .content .text .detail {
  font-size: 12px;
  font-weight: 500;
}
.vip :deep(.el-button--warning) {
  background-color: none;
  background-image: linear-gradient(to right, rgb(130, 86, 23), rgb(80, 51, 6));
  border: none;
  color: rgb(213, 179, 124);
}
.list {
  width: 100%;
  padding: 0 30px;
  margin-top: 20px;
  display: flex;
}
.list .item {
  width: 80px;
  height: 30px;
  margin-right: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.list .item p {
  font-size: 14px;
}
.list .item .icon {
  width: 50px;
  height: 50px;
}
.list .item .icon img {
  width: 100%;
}
</style>
