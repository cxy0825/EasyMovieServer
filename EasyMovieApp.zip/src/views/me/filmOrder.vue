<script setup>
import pageHeadVue from "@/components/pageHead.vue";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, computed } from "vue";
import order from "@/api/order/orderInfo.js";
import movieSet from "@/api/movie/movieSet.js";
//获取订单信息
const paymentInfo = reactive({
  data: [],
});
const router = useRouter();
order.getOrderList().then((res) => {
  paymentInfo.data = res;
  for (let item of paymentInfo.data) {
    movieSet.getMovieSetInfoByID(item.productId).then((res) => {
      item.cinemaName = res.cinemaName;
      item.filmName = res.filmName;
      item.filmId = res.filmId;
    });
  }
});

function toFilmView(filmID) {
  router.push(`/movie/${filmID}`);
}
</script>
<template>
  <div class="root">
    <div class="header">
      <pageHeadVue />
      <p>电影票</p>
    </div>
    <div class="list">
      <div class="item" v-for="(item, i) in paymentInfo.data" :key="i">
        <div class="header">
          <div class="title">{{ item.filmName }}</div>
          <div class="num">
            <span>{{ item.productNum }}</span> 张
          </div>
        </div>
        <div class="time">{{ item.callbackTime }}</div>
        <div class="set">
          <span v-for="(i, j) in JSON.parse(item.productInfo)" :key="j">
            {{ i[0] + 1 }}排{{ i[1] + 1 }}列
          </span>
        </div>
        <div class="footer">
          <div class="cinema">{{ item.cinemaName }}</div>
          <div class="button">
            <el-button
              type="danger"
              round
              size="small"
              @click="toFilmView(item.filmId)"
              >评论</el-button
            >
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.root {
  width: 100vw;
  height: 100vh;
  overflow-y: auto;
  background-color: rgb(242, 244, 245);
}
.root :deep(.pageHeader path) {
  fill: #000;
}
.root .header {
  background-color: #fff;
  width: 100%;
  height: 70px;
  overflow: hidden;
}
.header p {
  margin-top: 30px;
  text-align: center;
}
.list {
  width: 100%;
}
.list .item {
  width: 94%;
  /* height: 80px; */
  border-radius: 10px;
  overflow: hidden;
  background-color: #fff;
  margin: 20px auto 1px;
  padding: 15px 15px 10px;
}
.list .item .header {
  width: 100%;
  height: 25px;
  display: flex;
  justify-content: space-between;
}
.list .item .header .title {
  max-width: 80%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 16px;
  font-weight: bold;
  letter-spacing: 0.5px;
}
.list .item .header .num {
  font-size: 13px;
}
.list .item .header .num span {
  font-size: 19px;
  font-weight: bold;
}
.list .item .time {
  font-size: 12px;
  color: #d4d4d4;
  margin-bottom: 5px;
}
.list .item .set {
  display: flex;
  margin-bottom: 35px;
}
.list .item .set span {
  font-size: 12px;
  margin-right: 5px;
}
.list .item .footer {
  width: 100%;
  display: flex;
  font-size: 12px;
  justify-content: space-between;
  align-items: center;
  color: #989797;
  letter-spacing: 0.5px;
}
</style>
