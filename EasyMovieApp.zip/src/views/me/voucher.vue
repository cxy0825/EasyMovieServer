<script setup>
import pageHeadVue from "@/components/pageHead.vue";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, computed } from "vue";
import v from "@/api/voucher/voucherApi.js";

//获取订单信息
const voucher = reactive({
  data: [],
});
v.getVoucherByUser().then((res) => {
  voucher.data = res;
});
</script>
<template>
  <div class="root">
    <div class="header">
      <pageHeadVue />
      <p>优惠券</p>
    </div>
    <div class="list">
      <div class="item" v-for="(item, i) in voucher.data" :key="i">
        <!-- <div class="item"> -->
        <div class="left">
          <div class="title">{{ item.title }}</div>
          <div class="rule">使用规则: {{ item.rule }}</div>
          <div class="pay_value">使用金额: 满{{ item.payValue }}元可用</div>
        </div>
        <div class="right">
          <div>{{ item.actualValue }}元</div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.root {
  width: 100vw;
  height: 100vh;
  overflow-y: auto;
  background-color: rgb(242, 244, 245);
}
.root :deep(.pageHeader path) {
  fill: #000;
}
.root .header {
  background-color: #fff;
  width: 100%;
  height: 70px;
  overflow: hidden;
}
.header p {
  margin-top: 30px;
  text-align: center;
}
.list {
  width: 100%;
}
.list .item {
  width: 94%;
  /* height: 80px; */
  border-radius: 10px;
  overflow: hidden;
  background-color: #fff;
  margin: 20px auto 1px;
  padding: 15px 15px 10px;
  display: flex;
  justify-content: space-between;
}
.list .item .left {
  flex: 1 auto;
}
.list .item .left .title {
  width: 100%;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
  font-size: 16px;
  font-weight: bold;
  letter-spacing: 0.5px;
  margin-bottom: 5px;
}
.list .item .left .rule {
  font-size: 12px;
  color: #d4d4d4;
  margin-bottom: 5px;
}
.list .item .left .pay_value {
  font-size: 12px;
  color: #acabab;
  margin-bottom: 5px;
}
.list .item .right {
  width: 80px;
  border-left: 2px dashed #000;
  color: red;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  font-weight: 600;
  letter-spacing: 1px;
}
</style>
