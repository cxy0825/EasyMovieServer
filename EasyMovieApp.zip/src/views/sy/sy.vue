<script setup>
import headerSearch from "@/components/headerSearch.vue";
import { ref, reactive, onMounted, onActivated } from "vue";
import { useRouter, useRoute } from "vue-router";
import local from "@/api/local/localApi.js";
import movieApi from "@/api/movie/movieApi.js";
import { useMainStore } from "@/pinia/mainStore.js";
const mainStore = useMainStore();
const router = useRouter();
const route = useRoute();

//获取电影列表
//轮播图
const carouselList = ref([]);
//热点列表
const hotList = ref([]);
//推荐列表
const tjList = ref([]);
const page = ref(1);
const isShow = ref(false);
movieApi.getFilmINfoList(0, "-1", 1, 5).then((res) => {
  carouselList.value = res.records.slice(0, 5);
  hotList.value = res.records.reverse();
});
const load = () => {
  movieApi.getFilmINfoList(0, "-1", page.value, 4).then((res) => {
    tjList.value.push(...res.records.reverse());
    isShow.value = true;
  });
  page.value++;
};
//离开后记住滚动位置
//在挂载元素的时候开启监听滚动
const scrollBar = ref(0);
let body = null;

onMounted(() => {
  body = document.querySelector(".body");
  body.addEventListener("scroll", function (e) {
    scrollBar.value = this.pageYOffset || this.scrollTop || 0;
  });
  load();
});
function tocinemaView(name) {
  router.push();
}
//keep后不会执行生命周期但是会执行activated
onActivated(() => {
  // console.log(body);

  body.scrollTop = scrollBar.value;
});
</script>
<template>
  <div class="root">
    <headerSearch />
    <div class="body">
      <div class="carousel">
        <el-carousel :interval="4000" type="card" height="260px">
          <el-carousel-item v-for="(item, i) in carouselList" :key="i">
            <router-link :to="'/movie/' + item.id">
              <img :src="item.posterUrls[0]" />
            </router-link>
          </el-carousel-item>
        </el-carousel>
      </div>
      <div class="video">
        <div class="title">最新预告</div>
        <el-scrollbar>
          <div class="scrollbar-flex-content">
            <div
              class="scrollbar-flex-item"
              v-for="(item, i) in carouselList"
              :key="i"
            >
              <video controls>
                <source :src="item.videoUrls[0]" type="video/mp4" />
              </video>
              <div class="t">
                {{ item.filmName }}
              </div>
              <div class="rate">
                <span>评分: </span>
                {{ item.score }}分
              </div>
            </div>
          </div>
        </el-scrollbar>
      </div>
      <div class="hot">
        <div class="title">热播影片</div>
        <el-scrollbar>
          <div class="scrollbar-flex-content">
            <div
              class="scrollbar-flex-item"
              v-for="(item, i) in hotList"
              :key="i"
            >
              <router-link :to="'/movie/' + item.id">
                <img :src="item.posterUrls[0]" />
              </router-link>

              <div class="t">
                {{ item.filmName }}
              </div>
              <div class="btn">
                <el-button
                  type="danger"
                  round
                  @click="tocinemaView(item.filmName)"
                  >购票</el-button
                >
              </div>
            </div>
          </div>
        </el-scrollbar>
      </div>
      <div class="tj">
        <div class="title">为你推荐</div>
        <ul class="infinite-list">
          <li v-for="(item, i) in tjList" :key="i" class="infinite-list-item">
            <div class="img">
              <router-link :to="'/movie/' + item.id">
                <img :src="item.posterUrls[0]" />
              </router-link>
            </div>

            <div class="about">
              <span>{{ item.about }}</span>
            </div>
          </li>
        </ul>
        <div
          class="load"
          @click="load"
          style="
            width: 100%;
            text-align: center;
            font-size: 12px;
            margin-top: 5px;
            color: deepskyblue;
          "
        >
          点击加载更多
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import url("@/assets/static/css/sy.css");
</style>
