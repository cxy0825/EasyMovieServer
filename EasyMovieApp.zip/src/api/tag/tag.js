import request from "@/utils/request";

export default {
  async getTagList(page = 1, limit = 10) {
    return await request({
      url: `/movie/public/tag/Info/${page}/${limit}`,
      method: "GET",
    });
  },
  //根据名字查询标签
  async getTagInfoByName(name) {
    return await request({
      url: `http://localhost/movie/public/tag/Info`,
      method: "GET",
      params: {
        name: name,
      },
    });
  },
  async updateTag(data) {
    return await request({
      url: `http://localhost/movie/tag/save`,
      method: "POST",
      data: data,
    });
  },
  //添加电影标签
  async addTag(filmID, tagID) {
    return await request({
      url: `/movie/tag/add/film/${filmID}/${tagID}`,
      method: "POST",
    });
  },
  //删除电影标签
  async delTag(filmID, tagID) {
    return await request({
      url: `/movie/tag/del/film/${filmID}/${tagID}`,
      method: "DELETE",
    });
  },
};
