//电影排片相关操作API
import request from "@/utils/request";
export default {
  //查询片场信息列表
  async getMovieSetInfo(page = 1, limit = 10, cinemaId = null) {
    return await request({
      url: `/movie/public/movieSet/info/${page}/${limit}`,
      method: "GET",
      params: {
        cinemaId,
      },
    });
  },
  //通过排片ID删除排片信息
  async delMovieSet(ID) {
    return await request({
      url: `/movie/movieSet/delete/${ID}`,
      method: "DELETE",
    });
  },
  //根据ID查看片场信息
  async getMovieSetInfoByID(ID) {
    return await request({
      url: `/movie/public/movieSet/info/${ID}`,
      method: "GET",
    });
  },
  //根据ID获取片场信息(包含座位信息)
  async getMovieSetByID(ID) {
    return await request({
      url: `/movie/public/movieSet/info/all/${ID}`,
      method: "GET",
    });
  },
  //根据电影院ID和电影名字查看票价
  async getMovieSetInfoByName(cinemaID, filmName) {
    return await request({
      url: `/movie/public/movieSet/info/${filmName}/1/1`,
      method: "GET",
      params: {
        cinemaID,
      },
    });
  },
  //更改信息
  async updateMovieSetInfo(data) {
    return await request({
      url: `/movie/movieSet/update`,
      method: "POST",
      data: data,
    });
  },
  //添加片场信息
  async addMovieSetInfo(data) {
    return await request({
      url: `/movie/movieSet/add`,
      method: "POST",
      data: data,
    });
  },
  //获取今天的排片信息
  async getTodayInfo(cinemaID, filmID) {
    return await request({
      url: `/movie/public/movieSet/todayinfo/${cinemaID}/${filmID}`,
      method: "GET",
    });
  },
  //购票
};
