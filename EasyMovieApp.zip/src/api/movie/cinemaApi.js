import request from "@/utils/request";
export default {
  //获得电影放映厅列表
  async getCinemaInfo(x, y, page = 1, limit = 8, sort = "asc") {
    return await request({
      url: `/mongo/cinema/info`,
      method: "GET",
      params: {
        x,
        y,
        page,
        limit,
        sort,
      },
    });
  },
  //根据电影名字获得电影放映厅列表
  async getCinemaInfoByFilmName(
    x,
    y,
    filmName = "万里",
    page = 1,
    limit = 8,
    sort = "asc"
  ) {
    return await request({
      url: `/mongo/cinema/info/name`,
      method: "GET",
      params: {
        x,
        y,
        filmName,
        page,
        limit,
        sort,
      },
    });
  },
  //根据电影院ID获取电影院信息
  async getCinemaInfoByID(cinemaID = 1) {
    return await request({
      url: `/movie/cinema/public/info/${cinemaID}`,
      method: "GET",
    });
  },
};
