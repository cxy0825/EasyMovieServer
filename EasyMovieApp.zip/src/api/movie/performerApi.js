import request from "@/utils/request";
export default {
  //根据演员ID获取演员信息
  async getPerformerInfo(performerID) {
    return await request({
      url: `/movie/performer/public/performerInfo/${performerID}`,
    });
  },
  //根据电影ID获取演员信息
  async getPerformers(filmID) {
    return await request({
      url: `/movie/performer/public/info/${filmID}`,
    });
  },
  //根据演员ID获取演出过那些电影
  async getPerformInfo(performerID) {
    return await request({
      url: `/movie/performer/public/performInfo/${performerID}`,
    });
  },
  //查询演员列表
  async getPerformInfoList(page = 1, limit = 10, name = null) {
    return await request({
      url: `/movie/performer/public/info/list/${page}/${limit}`,
      method: "GET",
      params: { performerName: name },
    });
  },
  //对应电影下添加演员
  async addPerformer(filmID, performerID) {
    return await request({
      url: `/movie/performer/addPerformer`,
      method: "GET",
      params: { filmID, performerID },
    });
  },
  //删除演员
  async del(ID) {
    return await request({
      url: `/movie/performer/del/${ID}`,
      method: "GET",
    });
  },
  //根据ID删除影片下对应的演员
  async delIndex(filmID, performerID) {
    return await request({
      url: `/movie/performer/del/index`,
      method: "GET",
      params: {
        filmID,
        performerID,
      },
    });
  },
  //更新或者添加演员基本信息
  async update(data) {
    return await request({
      url: `/movie/performer/update`,
      method: "POST",
      data,
    });
  },
  //更新或者上传图片
  async upload(id, data) {
    return await request({
      url: `/movie/performer/upload/${id}`,
      method: "POST",
      data,
    });
  },
};
