//电影相关操作API
import request from "@/utils/request";
export default {
  //获得电影放映厅列表
  async getMoveHouseList(page = 1, size = 10, name = null) {
    return await request({
      url: `/movie/movieHouse/list/${page}/${size}`,
      method: "GET",
      params: {
        name: name,
      },
    });
  },
  //修改电影放映厅的信息
  async updateMoveHouse(data) {
    return await request({
      url: `/movie/movieHouse/addHouse`,
      method: "POST",
      data: data,
    });
  },
  //删除电影院
  async delMoveHouse(ID) {
    return await request({
      url: `/movie/movieHouse/deleteHouse/${ID}`,
      method: "DELETE",
    });
  },
  //根据电影放映厅ID获取放映厅信息(管理员用)
  async getMovueHouseInfoByID(ID) {
    return await request({
      url: `/movie/movieHouse/list/${ID}`,
      method: "GET",
    });
  },
  //根据电影放映厅ID获取放映厅信息(普通用户用)
  async getMovueHouse(ID) {
    return await request({
      url: `/movie/public/movieHouse/${ID}`,
      method: "GET",
    });
  },
  //根据ID查询电影放映厅的座位信息
  async getSeatInfoById(ID) {
    return await request({
      url: `/movie/public/movieHouse/info/${ID}`,
      method: "GET",
    });
  },
  //查询电影信息
  async getFilmINfoList(cinemaID = 0, name = "-1", page = 1, limit = 10) {
    return await request({
      url: `/movie/public/film/info/list/${cinemaID}/${name}/${page}/${limit}`,
      method: "GET",
    });
  },
  //根据ID查询电影信息
  async getFilmINfoById(ID) {
    return await request({
      url: `/movie/public/film/info/${ID}`,
      method: "GET",
    });
  },
  //根据电影ID查询电影演员信息
  async getPerformerByFilmID(ID) {
    return await request({
      url: `/movie/performer/public/info/${ID}`,
      method: "GET",
    });
  },
  //删除电影信息
  async delFilmInfo(filmID) {
    return await request({
      url: `/movie/film/del/${filmID}`,
      method: "DELETE",
    });
  },
  //上传海报
  async addPoster(filmID, data) {
    return await request({
      url: `/movie/filmInfo/poster/update/${filmID}`,
      method: "POST",
      data: data,
    });
  },
  //上传视频
  async addVideo(filmID, data) {
    return await request({
      url: `/movie/filmInfo/video/update/${filmID}`,
      method: "POST",
      data: data,
    });
  },
  //修改电影信息
  async updateMovieInfo(data) {
    return await request({
      url: `/movie/film/update`,
      method: "POST",
      data: data,
    });
  },
  //根据电影ID获得影片评论
  async getCommit(filmID) {
    return await request({
      url: `/mongo/commit/list`,
      method: "GET",
      params: { filmID },
    });
  },
  //发送评论
  async sendCommit(filmID, content) {
    return await request({
      url: `/mongo/commit/add`,
      method: "POST",
      data: { filmID, content },
    });
  },
};
