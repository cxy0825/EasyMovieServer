//用户相关操作API
import request from "@/utils/request";
export default {
  login(loginInfo) {
    return request({
      url: "/user/admin/login",
      method: "POST",
      data: loginInfo,
    });
  },
  async getInfo() {
    return await request({
      url: "/user/getInfo",
      method: "GET",
    });
  },
};
