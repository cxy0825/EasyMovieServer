//用户相关操作API
import request from "@/utils/request";
export default {
  login(loginInfo) {
    return request({
      url: "/user/login",
      method: "POST",
      data: loginInfo,
    });
  },
  async getCode(phone) {
    return await request({
      url: "/user/public/code",
      method: "GET",
      params: {
        phone,
      },
    });
  },
  async getInfo() {
    return await request({
      url: "/user/getInfo",
      method: "GET",
    });
  },
  //开通vip
  async openingVIP() {
    return await request({
      url: "/user/vip/open",
      method: "POST",
    });
  },
};
