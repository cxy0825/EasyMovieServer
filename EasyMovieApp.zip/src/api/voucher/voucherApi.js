//优惠券相关操作API
import request from "@/utils/request";
export default {
  //获得优惠券列表
  async getVoucherInfo(page = 1, limit = 10, params = {}) {
    return await request({
      url: `/order/voucher/voucherList/${page}/${limit}`,
      params,
    });
  },
  async updatedVoucher(data) {
    return await request({
      url: `/order/voucher/updateVoucher`,
      method: "POST",
      data,
    });
  },
  async delVoucher(ID) {
    return await request({
      url: `/order/voucher/deleteVoucher/${ID}`,
      method: "DELETE",
    });
  },
  //查询用户拥有的优惠券
  async getVoucherByUser(param = {}) {
    return await request({
      url: `/order/voucher/user`,
      method: "GET",
      param,
    });
  },
  //根据电影院ID查询优惠券
  async getVoucherByFilmID(cinemaID) {
    return await request({
      url: `/order/voucher/voucherList/${cinemaID}`,
      method: "GET",
    });
  },
};
