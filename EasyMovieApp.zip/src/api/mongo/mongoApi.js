import request from "@/utils/request";
export default {
  //查看所有的基金
  getAlljijing(page = 1, limit = 10) {
    return request({
      url: `http://localhost:1112/mongo/gongsi/all/${page}/${limit}`,
      method: "GET",
    });
  },

  //获得收藏
  getShouchang() {
    return request({
      url: `http://localhost:1112/mongo/user/shouchang`,
      method: "GET",
    });
  },

  //购买
  buy(ID, number, price) {
    return request({
      url: `http://localhost:1112/mongo/user/buy`,
      method: "GET",
      params: {
        ID,
        number,
        price,
      },
    });
  },
  //收藏
  sc(ID) {
    return request({
      url: `http://localhost:1112/mongo/user/shouchang/add/${ID}`,
      method: "GET",
    });
  },
  //取消收藏
  csc(ID) {
    return request({
      url: `http://localhost:1112/mongo/user/shouchang/q/${ID}`,
      method: "GET",
    });
  },

  //获得用户持有的基金
  getChiyou(value = null) {
    return request({
      url: "http://localhost:1112/mongo/user/chiyou",
      method: "GET",
      params: {
        value,
      },
    });
  },
  //卖出基金
  shell(ID) {
    return request({
      url: "http://localhost:1112/mongo/user/sell",
      method: "GET",
      params: {
        ID,
      },
    });
  },

  //全部公司
  all() {
    return request({
      url: "http://localhost:1112/mongo/gongsi/info/all",
      method: "GET",
    });
  },
  //根据公司ID获取基金
  getjjById(ID) {
    return request({
      url: `http://localhost:1112/mongo/gongsi/info/${ID}`,
      method: "GET",
    });
  },
};
