//电影票购买相关操作API
import request from "@/utils/request";
export default {
  //根据支付ID查询支付详情
  async getOrderInfo(paymentID) {
    return await request({
      url: `/order/payment/Info/${paymentID}`,
      method: "GET",
    });
  },
  //查询订单
  async getOrderList() {
    return await request({
      url: `/order/payment/Info/order/list`,
      method: "GET",
    });
  },
};
