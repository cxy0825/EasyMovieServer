//购买操作
import request from "@/utils/request";
export default {
  //购买电影票 (不限制数量)
  async buyTickets(movieSetId, tickets, voucherId = null) {
    return await request({
      url: `/order/aliPay/buy`,
      method: "POST",
      data: {
        movieSetId,
        tickets,
        voucherId,
      },
    });
  },
  //购买优惠券 (限制数量)
  async buyVoucher(id) {
    return await request({
      url: `/order/aliPay/limit/buyVoucher`,
      method: "POST",
      data: {
        id,
      },
    });
  },
  //创建支付宝订单
  async createZFBorder(paymentID) {
    return await request({
      url: `/order/aliPay/pay/${paymentID}`,
      method: "GET",
    });
  },
};
