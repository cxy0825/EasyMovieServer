import request from "@/utils/localRequest.js";

export default {
  //IP信息转换为地理位置信息。
  async getlocal() {
    return await request({
      //   url: `https://restapi.amap.com/v3/ip`,
      url: `v3/ip`,
      method: "GET",
    });
  },
};
