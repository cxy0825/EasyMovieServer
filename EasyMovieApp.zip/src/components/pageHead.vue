<script setup>
import { useRouter, useRoute } from "vue-router";
const router = useRouter();
function goBack() {
  router.go(-1);
}
</script>
<template>
  <div class="pageHeader">
    <el-page-header @back="goBack" title=" "> </el-page-header>
  </div>
</template>

<style scoped>
.pageHeader {
  padding: 0 15px;
  width: 100vw;
  position: fixed;
  top: 30px;
  left: 0;
  z-index: 10000;
}
.pageHeader >>> .el-divider {
  display: none;
}
.pageHeader >>> .el-icon {
  transform: scale(1.2);
}
.pageHeader >>> .el-icon path {
  fill: white;
}
</style>
