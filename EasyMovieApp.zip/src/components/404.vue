<script setup></script>
<template>
  <div>404</div>
</template>

<style scoped></style>
