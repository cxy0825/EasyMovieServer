<script setup>
import { ref, reactive, onMounted, onActivated } from "vue";
import { useRouter, useRoute } from "vue-router";
import local from "@/api/local/localApi.js";
import movieApi from "@/api/movie/movieApi.js";
import { useMainStore } from "@/pinia/mainStore.js";
import { locale } from "dayjs";
const mainStore = useMainStore();
const router = useRouter();
const route = useRoute();
//默认城市
const city = ref("台州市");
const searchKey = ref("");
//获取当前地理位置
local.getlocal().then((res) => {
  city.value = res.city;
  let arr = [];
  //pc端不能获取准确的位置所以取中间值
  for (let item of res.rectangle.split(";")) {
    arr.push(item.split(","));
  }
  let y = (Number(arr[0][0]) + Number(arr[1][0])) / 2;
  let x = (Number(arr[0][1]) + Number(arr[1][1])) / 2;
  console.log("当前地址", x + "," + y);
  mainStore.location = x + "," + y;
});
function search() {
  // console.log(searchKey.value.trim());

  if (searchKey.value.trim() != "") {
    router.push("/main/cinema/" + searchKey.value);
  } else {
    router.push("/main/cinema");
  }
}
</script>
<template>
  <div class="header">
    <div class="city">{{ city }}</div>
    <div class="search">
      <el-input
        placeholder="请输入电影名字"
        class="search"
        v-model="searchKey"
        @change="search"
      />
      <div class="search-btn">
        <el-button round @click="search">搜索</el-button>
      </div>
    </div>
    <div class="s"></div>
  </div>
</template>

<style scoped>
.header {
  width: 100vw;
  height: 90px;
  background-color: rgb(34, 34, 34);
  padding: 30px 15px 0;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
}
.header::after {
  width: 100%;
  height: 50px;
  content: "";
  background-color: rgb(34, 34, 34);
  position: absolute;
  top: 60px;
  left: 0;

  z-index: -1;
}
.header .city {
  font-size: 14px;
}
.header .search {
  padding: 0 5px;
  flex: 1;
  position: relative;
}
.search :deep(.el-input__wrapper) {
  border-radius: 20px;
}

.header .search .search-btn {
  position: absolute;
  right: 8px;
  top: 0;
}
.search :deep(.search-btn .el-button) {
  background-color: rgba(59, 59, 59);
  color: rgb(224, 208, 184);
  border: none;
}

.header .s {
  width: 30px;
}
</style>
