<!-- 放映厅位置信息 -->
<script setup>
import { useRouter, useRoute } from "vue-router";
import { ref, reactive, toRefs, isReactive, computed } from "vue";
import movie from "@/api/movie/movieApi.js";
import movieSet from "@/api/movie/movieSet.js";
import { ElMessage, ElLoading } from "element-plus";
import { useMainStore } from "@/pinia/mainStore";
const mainStore = useMainStore();

const router = useRouter();
const route = useRoute();
// const id = route.params.id;
//父组件传递过来的状态值 1表示购买票 2表示维修中
const prop = defineProps({
  movieHouseID: {
    default: 1,
  },
  movieSetID: {
    //已经购买过的座位
    default: 1,
    type: String,
  },
});

//传递给父组件
const emit = defineEmits(["change"]);

//拿到ID后查询
//稀疏数组第一项表示 有行 几列 多少条数据
const dataHeader = reactive([]);
//稀疏数组数据部分
const dataBody = reactive([]);

//要提交的数据
const sub = reactive([]);
//渲染维修数据
movie.getSeatInfoById(prop.movieHouseID).then((res) => {
  dataHeader.push(...res.seatInfo[0]);
  if (res.seatInfo.length > 1) {
    res.seatInfo.splice(0, 1);
    dataBody.push(...res.seatInfo);
  }
  console.log(dataBody);
});
//渲染已经购买的座位的位置
movieSet.getMovieSetByID(prop.movieSetID).then((res) => {
  dataBody.push(...res.seatInfo);
});
//判断数组是不是在二维数组中
const hasArr = function (arr, arrs) {
  for (let a of arrs) {
    if (a[0] == arr[0] && a[1] == arr[1] && a[2] == arr[2]) {
      return true;
    }
  }
  return false;
};

const change = function (row, col, checked) {
  console.log("选中的索引", row, col);
  //如果是选中就把他添加到sub中
  if (checked == "true") {
    console.log("添加选中");
    sub.push([row, col]);
  }
  //如果是false就表示取消选中
  else {
    console.log("删除选中");
    for (let i = 0; i < sub.length; i++) {
      if (sub[i][0] == row && sub[i][1] == col) {
        // console.log(sub[i]);
        sub.splice(i, 1);
      }
    }
  }
  emit("change", sub);
  // console.log(sub);
};
</script>
<template>
  <div class="seatContainer">
    <div class="p">
      <img src="@/assets/static/img/荧幕.png" alt="" />
      <div class="text">屏幕中心</div>
    </div>
    <el-row class="rowHeader">
      <el-col class="colIndex" style="visibility: hidden">0</el-col>
      <el-col class="colIndex" v-for="(item, index) in dataHeader[1]">{{
        item
      }}</el-col>
    </el-row>
    <el-row
      class="row"
      v-for="(rowItem, index) in dataHeader[0]"
      :key="`row-` + index"
    >
      <el-col class="col">{{ rowItem }}</el-col>
      <el-col
        v-for="(colItem, index) in dataHeader[1]"
        class="col"
        :key="`col-` + index"
      >
        <div
          :class="{
            seatIcon: true,
            select: hasArr([rowItem - 1, colItem - 1], sub),
            buy: hasArr([rowItem - 1, colItem - 1, 1], dataBody),
            fix: hasArr([rowItem - 1, colItem - 1, 2], dataBody),
          }"
        ></div>
        <!-- 任何人都不能选中已经购买的座位 -->
        <!-- 只有管理员才能选中正在维修的按钮 -->
        <el-checkbox
          size="large"
          :disabled="
            hasArr([rowItem - 1, colItem - 1, 1], dataBody) ||
            hasArr([rowItem - 1, colItem - 1, 2], dataBody) ||
            mainStore.power == null ||
            mainStore.power == undefined
          "
          true-label="true"
          false-label="false"
          @change="(checked) => change(rowItem - 1, colItem - 1, checked)"
        />
      </el-col>
    </el-row>
    <div class="foot">
      <div class="not">
        <div class="icon">
          <img src="@/assets/static/img/可选.png" alt="" />
        </div>
        <div class="text">可选</div>
      </div>
      <div class="it">
        <div class="icon">
          <img src="@/assets/static/img/已经购买.png" alt="" />
        </div>
        <div class="text">已经购买</div>
      </div>
      <div class="fix">
        <div class="icon">
          <img src="@/assets/static/img/正在维修.png" alt="" />
        </div>
        <div class="text">正在维修</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.seatContainer {
  width: 100%;
  padding: 20px;
  position: relative;
}
.p {
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: center;
  align-self: center;
  flex-direction: column;
  margin-bottom: 50px;
}
.p .text {
  text-align: center;
  color: rgb(180, 180, 180);
  font-size: 15px;
  font-weight: 600;
}
.seatContainer .rowHeader {
  width: 100%;
  height: 20px;
  font-size: 14px;
  color: rgb(180, 180, 180);
  display: flex;
  justify-content: space-evenly;
}
.seatContainer .rowHeader .colIndex {
  width: 20px;
  height: 20px;
  flex: 0 0 0;
}
.seatContainer .row {
  width: 100%;
  height: 30px;
  font-size: 14px;
  color: rgb(180, 180, 180);
  display: flex;
  justify-content: space-evenly;
  margin-top: 8px;
}
.seatContainer .row .col {
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 30px;
  height: 30px;
  flex: 0 0 0;
  position: relative;
}
.el-checkbox {
  width: 30px;
  height: 30px;
  opacity: 0;
}
.el-checkbox >>> .el-checkbox__inner {
  width: 30px;
  height: 30px;
}
.col .seatIcon {
  width: 100%;
  height: 100%;
  position: absolute;
  z-index: 100;
  background-image: url(@/assets/static/img/可选.png);
  background-position: center;
  background-size: cover;
  /* background-origin: containers; */
  border-radius: 6px;
  pointer-events: none;
  cursor: pointer;
}
.col .select {
  background-image: url(@/assets/static/img/已选.png) !important;
}
.col .buy {
  background-image: url(@/assets/static/img/已经购买.png);
}
.col .fix {
  background-image: url(@/assets/static/img/正在维修.png);
}
.foot {
  width: 100%;
  height: 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 30px;
  justify-content: space-around;
}
.foot > div {
  display: flex;

  align-items: center;
}
.foot > div img {
  width: 30px;
  height: 30px;
}
.foot > div .text {
  font-size: 14px;
}
</style>
