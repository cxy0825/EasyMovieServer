<script setup>
import { ref, reactive } from "vue";
import { useRoute, useRouter } from "vue-router";
const route = useRoute();
const router = useRouter();

const index = ref(1);
function switchView(i, path) {
  index.value = i;
  router.push(path);
}
</script>
<template>
  <div class="main">
    <router-view v-slot="{ Component }" class="view">
      <keep-alive>
        <component
          :is="Component"
          v-if="route.meta.keepAlive"
          :key="route.name"
        />
      </keep-alive>
      <component
        :is="Component"
        v-if="!route.meta.keepAlive"
        :key="route.name"
      />
    </router-view>

    <div class="nav">
      <div class="item" @click="switchView(1, '/main/sy')">
        <div class="img">
          <div class="normal">
            <img src="@/assets/static/img/首页-normal.png" alt="" />
          </div>
          <div class="select" v-show="route.fullPath == '/main/sy'">
            <img src="@/assets/static/img/首页-select.png" alt="" />
          </div>
        </div>
        <div class="title">首页</div>
      </div>
      <div class="item" @click="switchView(2, '/main/cinema')">
        <div class="img">
          <div class="normal">
            <img src="@/assets/static/img/电影院-normal.png" alt="" />
          </div>
          <div class="select" v-show="route.fullPath == '/main/cinema'">
            <img src="@/assets/static/img/电影院-select.png" alt="" />
          </div>
        </div>
        <div class="title">影院</div>
      </div>
      <div class="item" @click="switchView(3, '/main/me')">
        <div class="img">
          <div class="normal">
            <img src="@/assets/static/img/我的-normal.png" alt="" />
          </div>
          <div class="select" v-show="route.fullPath == '/main/me'">
            <img src="@/assets/static/img/我的-select.png" alt="" />
          </div>
        </div>
        <div class="title">我的</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.main {
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
}
.view {
  height: 100vh;
  position: relative;
}
.nav {
  width: 100vw;
  height: 50px;
  /* background-color: royalblue; */
  display: flex;
  justify-content: space-around;
  border-top: 1px solid rgb(243, 243, 243);
  box-shadow: 0px -4px 20px 3px rgb(66 66 66 / 60%);
  position: relative;
  z-index: 1000;
}
.nav > div {
  width: 80px;
  display: flex;

  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.nav > div .img {
  position: relative;
  width: 25px;
  height: 25px;
}
.nav > div .img img {
  width: 100%;
  position: absolute;
}
.nav > div .title {
  width: 50px;
  font-size: 12px;
  text-align: center;
}
</style>
