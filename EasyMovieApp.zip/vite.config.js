import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";

import path from "path"; // 导入 path 模块，帮助我们解析路径
// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    open: true,
    port: 1111,
    host: "0.0.0.0",
    proxy: {
      "/local": {
        target: "https://restapi.amap.com",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/local/, ""),

        // pathRewrite: {
        //   // 重写代理路径
        //   // 就是把路径中的/local都替换为空的字符串
        //   "/local": "", // 因为服务端地址里面是没有api字段的，api只是为了区别需要代理的路径，如果服务端有api字段则不需要重新
        // },
      },
    },
  },
});
